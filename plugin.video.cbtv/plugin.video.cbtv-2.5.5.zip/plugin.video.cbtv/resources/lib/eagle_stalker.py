import requests
import re
import xbmc
import os
import json
import time
import random
import xbmcaddon
import xbmcvfs
import concurrent.futures
import hashlib

# --- CONFIGURAZIONE SORGENTE EB ---
# URL remoto che Eagle Blvck usa per aggiornare portale e MAC
_EB_CONFIG_URL = "http://blacktruck.atspace.cc/api.blvck.xml"

# Fallback hardcoded (aggiornati al 2026-04-05)
_FALLBACK_PORTAL = "http://majestic-ott.com:80/c/"
_FALLBACK_MAC = "00:1A:79:25:61:1e"

def _fetch_eb_config():
    """Scarica la config dinamica dal server Eagle Blvck (stesso file usato dall'addon ufficiale)"""
    try:
        r = requests.get(_EB_CONFIG_URL, timeout=8)
        if r.status_code == 200:
            text = r.text
            # Estrai portal URL (formato: portal"http://...")
            portal_m = re.search(r'portal"(http[^"]+)"', text)
            # Estrai MAC addresses (formato: 00:1A:79:xx:xx:xx)
            macs = re.findall(r'(00:1[Aa]:79:[0-9A-Fa-f:]{8})', text)
            if portal_m and macs:
                portal = portal_m.group(1)
                if not portal.endswith('/c/'):
                    portal = portal.rstrip('/') + '/c/'
                mac = random.choice(macs)
                xbmc.log(f"[CBTV] EB Config dinamica: portal={portal}, mac={mac}", xbmc.LOGINFO)
                return portal, mac
    except Exception as e:
        xbmc.log(f"[CBTV] EB Config fetch fallita: {e}. Uso fallback.", xbmc.LOGWARNING)
    return _FALLBACK_PORTAL, _FALLBACK_MAC

# Inizializza con fetch dinamico
PORTAL_URL, MAC_ADDRESS = _fetch_eb_config()
ADDON_ID = 'plugin.video.cbtv'

def clean_text(text):
    """Rimuove simboli speciali ed emoticon preservando i nomi commerciali (Sky, Fox, etc.)"""
    if not text: return ""
    cleaned = "".join(c for c in text if ord(c) < 128 or c in "àèìòùÀÈÌÒÙ")
    cleaned = re.sub(r'^[A-Z]{2,3}\s*[\-\|]\s*', '', cleaned)
    cleaned = re.sub(r'^[A-Z]{2,2}\s+(?=[A-Z])', '', cleaned)
    cleaned = cleaned.replace("FHD", "HD").replace("fhd", "hd")
    return cleaned.replace('  ', ' ').strip()

class EagleStalkerClient:
    _UA = 'Mozilla/5.0 (QtEmbedded; U; Linux; C) AppleWebKit/533.3 (KHTML, like Gecko) MAG200 stbapp ver: 4 rev: 1812 Mobile Safari/533.3'
    _TIMEZONE = 'Europe%2FBerlin'
    _MAX_RETRIES = 2
    
    _MAC_POOL = [
        MAC_ADDRESS,
        "00:1A:79:47:75:A1",
        "00:1A:79:41:A2:9A",
        "00:1A:79:33:04:0A",
        "00:1A:79:2C:22:11"
    ]

    def __init__(self, portal=PORTAL_URL, mac=None):
        self.portal = portal
        self.mac = mac or self._MAC_POOL[0]
        self._token = None
        self._token_time = 0
        
        # Identità fissa deterministica per evitare conflitti di sessione
        self.serial = hashlib.md5(f"{ADDON_ID}_serial".encode()).hexdigest()[:15].upper()
        self.device_id = hashlib.md5(f"{ADDON_ID}_device".encode()).hexdigest().upper()
        
        self.headers = {
            'User-Agent': self._UA,
            'X-User-Agent': 'Model: MAG254; Link: Ethernet',
            'Referer': self.portal,
            'Accept': '*/*',
            'Connection': 'Keep-Alive'
        }
        self.update_mac_headers(self.mac)
        
        profile = xbmcvfs.translatePath(xbmcaddon.Addon().getAddonInfo('profile'))
        if not os.path.exists(profile): os.makedirs(profile)
        self.cache_dir = profile

    def update_mac_headers(self, mac):
        self.mac = mac
        self.headers['Cookie'] = f'mac={mac}; stb_lang=en; timezone={self._TIMEZONE}'

    def _handshake(self):
        """Ottiene un token dal portale tramite handshake con identità MAG simulata"""
        params = {
            'type': 'stb',
            'action': 'handshake',
            'token': '',
            'JsHttpRequest': '1-xml'
        }
        h = dict(self.headers)
        h['Authorization'] = '' 

        try:
            r = requests.get(f"{self.portal}portal.php", params=params, headers=h, timeout=15)
            info = r.json()
            token = info.get('js', {}).get('token')
            if token:
                self._token = token
                self._token_time = time.time()
                return token
        except Exception as e:
            xbmc.log(f"[CBTV] EB Handshake Error ({self.mac}): {e}", xbmc.LOGERROR)
        return None

    def _get_token(self, force_refresh=False):
        if not force_refresh and self._token and (time.time() - self._token_time) < 1800:
            return self._token
        return self._handshake()

    def _get_cache(self, key):
        cache_file = os.path.join(self.cache_dir, f"eb_cache_{key}.json")
        if os.path.exists(cache_file):
            try:
                with open(cache_file, 'r', encoding='utf-8') as f:
                    data = json.load(f)
                    if time.time() - data.get('timestamp', 0) < 43200:
                        return data.get('content')
            except: pass
        return None

    def _set_cache(self, key, content):
        cache_file = os.path.join(self.cache_dir, f"eb_cache_{key}.json")
        try:
            with open(cache_file, 'w', encoding='utf-8') as f:
                json.dump({'timestamp': time.time(), 'content': content}, f)
        except: pass

    def _call(self, action, params=None):
        if params is None: params = {}
        final_params = {'type': 'itv', 'action': action}
        final_params.update(params)
        
        mac_attempts = [self.mac] + [m for m in self._MAC_POOL if m != self.mac] if action == "create_link" else [self.mac]
        
        for current_mac in mac_attempts:
            self.update_mac_headers(current_mac)
            retries = 0
            while retries <= self._MAX_RETRIES:
                token = self._get_token(force_refresh=(retries > 0))
                if not token: break
                
                h = dict(self.headers)
                h['Authorization'] = f'Bearer {token}'
                try:
                    r = requests.get(f"{self.portal}portal.php", headers=h, params=final_params, timeout=20)
                    if r.status_code == 200:
                        res = r.json().get('js', {})
                        if 'Authorization failed' in str(res):
                            self._token = None
                            retries += 1
                            continue
                        return res
                except:
                    retries += 1
            if action == "create_link":
                xbmc.log(f"[CBTV] EB Rotate MAC: {current_mac} fallito, provo il prossimo...", xbmc.LOGWARNING)
        return {}

    def generate_stream_link(self, cmd):
        """Genera il link e invia il segnale 'start' per attivare lo stream sul portale"""
        # 1. Ottieni il link
        # Nota: usiamo forced_storage=0 e download=0 per simulare un player live MAG
        res = self._call("create_link", {'cmd': cmd, 'forced_storage': '0', 'download': '0'})
        url = res.get('cmd', '')
        if not url: return None
        
        stream_url = url.split(" ")[1] if " " in url else url
        
        # 2. SEGNALE 'START' (Fondamentale in molti portali Stalker per non far cadere lo stream)
        try:
            self._call("log", {
                'type': 'stb', 
                'sub': 'play_started', 
                'cmd': cmd,
                'ch_id': cmd.split("/")[-1] if "/" in cmd else "0"
            })
        except: pass
        
        return stream_url

    def get_categories(self, force_refresh=False):
        if not force_refresh:
            cached = self._get_cache("categories")
            if cached: return cached
        res = self._call("get_genres")
        if res: self._set_cache("categories", res)
        return res

    def get_channels_by_genre(self, genre_id, page=1):
        params = {'action': 'get_ordered_list', 'genre': genre_id, 'p': str(page)}
        return self._call("get_ordered_list", params)

    def get_sky_tv_channels(self, force_refresh=False):
        cache_key = "sky_tv_v5"
        if not force_refresh:
            cached = self._get_cache(cache_key)
            if cached: return cached
        keywords = ["SKY ", "ATLANTIC", "SERIE", "LIFE", "COMEDY", "ACTION", "DRAMA", "FAMILY", "ROMANCE", "SUSPENSE", "COLLECTION", "CINEMA", "UNO", "NATURE", "DOCUMENTARI", "INVESTIGATION", "ARTE"]
        def fetch_page(page):
            res = self.get_channels_by_genre(5, page)
            return res.get('data', []) if res else []
        found = []
        seen_cmds = set()
        with concurrent.futures.ThreadPoolExecutor(max_workers=10) as executor:
            futures = [executor.submit(fetch_page, p) for p in range(1, 21)]
            for future in concurrent.futures.as_completed(futures):
                data = future.result()
                for ch in data:
                    cmd = ch.get('cmd')
                    if cmd in seen_cmds: continue
                    name_raw = ch.get('name', '')
                    name_up = name_raw.upper()
                    is_sky_tv = any(k in name_up for k in keywords)
                    is_sport_dazn = any(x in name_up for x in ["SPORT", "DAZN", "CALCIO", "EUROSPORT", "ZONA"])
                    is_national = any(x in name_up for x in ["RAI", "ITALIA 1", "RETE 4", "CANALE 5", "LA7", "TV8", "NOVE", "FOX"])
                    if is_sky_tv and not is_sport_dazn and not is_national:
                        found.append({'name': clean_text(name_raw), 'cmd': cmd, 'category': 'Sky TV'})
                        seen_cmds.add(cmd)
        found.sort(key=lambda x: x['name'])
        self._set_cache(cache_key, found)
        return found

    def get_sky_sport_channels(self, force_refresh=False):
        cache_key = "sky_sport_v4"
        if not force_refresh:
            cached = self._get_cache(cache_key)
            if cached: return cached
        keywords = ["SKY SPORT", "EUROSPORT", "ZONA DAZN"]
        def fetch_page(page):
            res = self.get_channels_by_genre(5, page)
            return res.get('data', []) if res else []
        found = []
        seen_cmds = set()
        with concurrent.futures.ThreadPoolExecutor(max_workers=10) as executor:
            futures = [executor.submit(fetch_page, p) for p in range(1, 21)]
            for future in concurrent.futures.as_completed(futures):
                data = future.result()
                for ch in data:
                    cmd = ch.get('cmd')
                    if cmd in seen_cmds: continue
                    name_raw = ch.get('name', '')
                    name_up = name_raw.upper()
                    if any(k in name_up for k in keywords):
                        found.append({'name': clean_text(name_raw), 'cmd': cmd, 'category': 'Sky Sport'})
                        seen_cmds.add(cmd)
        found.sort(key=lambda x: x['name'])
        self._set_cache(cache_key, found)
        return found

    def get_dazn_channels(self, force_refresh=False):
        cache_key = "dazn_v4"
        if not force_refresh:
            cached = self._get_cache(cache_key)
            if cached: return cached
        def fetch_page(page):
            res = self.get_channels_by_genre(5, page)
            return res.get('data', []) if res else []
        found = []
        seen_cmds = set()
        with concurrent.futures.ThreadPoolExecutor(max_workers=10) as executor:
            futures = [executor.submit(fetch_page, p) for p in range(1, 21)]
            for future in concurrent.futures.as_completed(futures):
                data = future.result()
                for ch in data:
                    cmd = ch.get('cmd')
                    if cmd in seen_cmds: continue
                    name_raw = ch.get('name', '')
                    name_up = name_raw.upper()
                    if "DAZN" in name_up:
                        found.append({'name': clean_text(name_raw), 'cmd': cmd, 'category': 'DAZN'})
                        seen_cmds.add(cmd)
        found.sort(key=lambda x: x['name'])
        self._set_cache(cache_key, found)
        return found

    def get_intl_eb_list2(self, force_refresh=False):
        cache_key = "list2_v7" 
        if not force_refresh:
            cached = self._get_cache(cache_key)
            if cached: return cached
        all_genres = self.get_categories(force_refresh=force_refresh)
        itinerary = {
            "Polonia": {"genres": ["POLAND"], "keywords": ["POLSAT SPORT"]},
            "Bulgaria": {"genres": ["BULGARIA"], "keywords": ["MAX SPORT"]},
            "Olanda": {"genres": ["NEDERLAND"], "keywords": ["ZIGGO SPORT"]}
        }
        def fetch_page(genre, page, nation):
            res = self.get_channels_by_genre(genre['id'], page)
            return (res.get('data', []), genre, nation) if res else ([], genre, nation)
        tasks = []
        final_structure = {n: [] for n in itinerary}
        for nation, config in itinerary.items():
            target_genres = [g for g in all_genres if any(k in g.get('title','').upper() for k in config["genres"])]
            for g in target_genres:
                for p in range(1, 11): tasks.append((g, p, nation))
        with concurrent.futures.ThreadPoolExecutor(max_workers=10) as executor:
            future_to_page = {executor.submit(fetch_page, g, p, n): (g, p, n) for g, p, n in tasks}
            for future in concurrent.futures.as_completed(future_to_page):
                data, genre, nation = future.result()
                config = itinerary[nation]
                for ch in data:
                    name_up = ch.get('name', '').upper()
                    if any(k in name_up for k in config["keywords"]):
                        final_structure[nation].append({'name': clean_text(ch.get('name')), 'cmd': ch.get('cmd'), 'category': clean_text(genre.get('title'))})
        for n in final_structure: final_structure[n].sort(key=lambda x: x['name'])
        self._set_cache(cache_key, final_structure)
        return final_structure
