import sys
from urllib.parse import parse_qsl, urlencode
import xbmcgui
import xbmcplugin
import json
import re
import xbmc
import base64
from resources.lib.scraper import get_oasport_events

import xbmcaddon
import os

# Global variables
ADDON = xbmcaddon.Addon()
ADDON_ID = 'plugin.video.cbtv'
HANDLE = int(sys.argv[1])
BASE_URL = sys.argv[0]

# Ensure absolute path for fanart
FANART = os.path.join(ADDON.getAddonInfo('path'), 'fanart.jpg')

# URL config remota su GitHub Pages
REMOTE_CONFIG_URL = "https://cb6-maker.github.io/repo.cbtv/channels_config.json"

# Cache config per evitare download multipli nella stessa sessione
_cached_config = None

def get_remote_config():
    """Scarica la config remota da GitHub. Se fallisce, usa i default hardcoded."""
    global _cached_config
    if _cached_config is not None:
        return _cached_config
    
    import requests
    try:
        xbmc.log(f"[CBTV] Scaricando config da {REMOTE_CONFIG_URL}", xbmc.LOGINFO)
        r = requests.get(REMOTE_CONFIG_URL, timeout=5)
        if r.status_code == 200:
            _cached_config = r.json()
            xbmc.log(f"[CBTV] Config remota caricata (v{_cached_config.get('version', '?')})", xbmc.LOGINFO)
            return _cached_config
    except Exception as e:
        xbmc.log(f"[CBTV] Config remota non disponibile: {e}. Uso defaults.", xbmc.LOGWARNING)
    
    # Fallback hardcoded
    _cached_config = DEFAULT_CONFIG
    return _cached_config

# Default hardcoded (usato se GitHub non risponde)
DEFAULT_CONFIG = {
    "version": 0,
    "freeshot": {
        "player_base_url": "https://popcdn.day/player/",
        "stream_base_url": "https://planetary.lovecdn.ru/",
        "stream_path": "/tracks-v1a1/mono.m3u8",
        "referer": "https://thisnot.business/",
        "token_regex": 'currentToken: "([^"]+)"',
        "channels": [
            {"name": "Sky Sport 24", "code": "SkySport24IT"},
            {"name": "Sky Sport Uno", "code": "SkySportUnoIT"},
            {"name": "Sky Sport Calcio", "code": "SkySportCalcioIT"},
            {"name": "Sky Sport Arena", "code": "SkySportArenaIT"},
            {"name": "Sky Sport Max", "code": "SkySportMaxIT"},
            {"name": "Sky Sport Tennis", "code": "SkySportTennisIT"},
            {"name": "Sky Sport F1", "code": "SkySportF1IT"},
            {"name": "Sky Sport MotoGP", "code": "SkySportMotoGPIT"},
            {"name": "Sky Sport Basket", "code": "SkySportBasketIT"},
            {"name": "Sky Sport Golf", "code": "SkySportGolfIT"},
            {"name": "DAZN", "code": "ZonaDAZN"},
        ]
    },
    "mediahosting": {
        "embed_base_url": "https://mediahosting.space/embed/player?stream=",
        "referer": "https://mediahosting.space/",
        "source_regex": '<source src="(.*?)"',
        "channels": [
            {"name": "Sky Sport 24", "code": "238"},
            {"name": "Sky Sport Uno", "code": "230"},
            {"name": "Sky Sport Calcio", "code": "232"},
            {"name": "Sky Sport Arena", "code": "235"},
            {"name": "Sky Sport Max", "code": "236"},
            {"name": "Sky Sport Tennis", "code": "233"},
            {"name": "Sky Sport F1", "code": "231"},
            {"name": "Sky Sport MotoGP", "code": "234"},
            {"name": "Sky Sport Basket", "code": "239"},
            {"name": "Sky Sport Golf", "code": "237"},
            {"name": "DAZN", "code": "229"},
        ]
    }
}

def build_url(query):
    return f"{BASE_URL}?{urlencode(query)}"

def add_directory_item(title, query, is_folder=True, icon=None, is_playable=False):
    url = build_url(query)
    list_item = xbmcgui.ListItem(label=title)
    
    # Set default fanart for everything
    art = {'fanart': FANART}
    if icon:
        art['icon'] = icon
        art['thumb'] = icon
    list_item.setArt(art)

    if is_playable:
        list_item.setProperty('IsPlayable', 'true')
    xbmcplugin.addDirectoryItem(handle=HANDLE, url=url, listitem=list_item, isFolder=is_folder)

def main_menu():
    xbmcplugin.setContent(HANDLE, 'videos')
    
    add_directory_item("[COLOR lime][B]Agenda Sportiva (Eventi di Oggi)[/B][/COLOR]", {"action": "list_agenda"})
    add_directory_item("[COLOR gold][B]Canali Sport[/B][/COLOR]", {"action": "list_sport"})
    add_directory_item("[COLOR yellow][B]Cinema e Intrattenimento[/B][/COLOR]", {"action": "list_premium_cinema"})
    
    xbmcplugin.endOfDirectory(HANDLE)

def list_sport():
    """Sottomenu Sport con tutte le sorgenti"""
    xbmcplugin.setContent(HANDLE, 'videos')
    
    add_directory_item("[COLOR lime][B]Sport Premium[/B][/COLOR]", {"action": "list_premium_sport"})
    add_directory_item("[COLOR gold][B]Sport SKY[/B][/COLOR]", {"action": "list_sport_sky"})
    add_directory_item("[COLOR cyan][B]Sport MPD Nazioni[/B][/COLOR]", {"action": "list_mpd_nazioni"})
    
    xbmcplugin.endOfDirectory(HANDLE)

def list_sport_sky():
    """Sottomenu Sky con le due sorgenti disponibili"""
    xbmcplugin.setContent(HANDLE, 'videos')
    
    add_directory_item("[COLOR gold][B]Sky Sport LIVE[/B][/COLOR] (Fonte 1)", {"action": "list_freeshot"})
    add_directory_item("[COLOR orange][B]Sky Sport 2[/B][/COLOR] (Fonte 2)", {"action": "list_mediahosting"})
    
    xbmcplugin.endOfDirectory(HANDLE)

# --- PREMIUM (MANDRAKODI SOURCE) ---

# Hardcoded config (no remote fetch to avoid load-time issues)
PREMIUM_URL = "https://test34344.herokuapp.com/filter.php"
PREMIUM_UA = "MandraKodi2@@1.1.2@@MandraKodi3@@S63TDC"
PROTECTION_KEY = "amstaff@@"

def list_premium_sport():
    """Show SPORT premium channels directly (no subfolder)"""
    import requests
    xbmcplugin.setContent(HANDLE, 'videos')
    url = f"{PREMIUM_URL}?numTest=A1A260"
    headers = {"User-Agent": PREMIUM_UA}
    
    try:
        r = requests.get(url, headers=headers, timeout=10)
        data = r.json()
        sections = data.get("channels", [])
        
        for sec in sections:
            name = sec.get("name", "Unknown Group")
            # Show channels directly from SPORT sections
            if "SPORT" in name.upper():
                for it in sec.get("items", []):
                    resolve_val = it.get("myresolve", "")
                    if PROTECTION_KEY in resolve_val:
                        payload = resolve_val.split("@@")[1]
                        title = it.get("title", "Canale")
                        add_directory_item(
                            title, 
                            {"action": "play_premium", "payload": payload, "title": title},
                            is_folder=False,
                            is_playable=True,
                            icon=it.get("thumbnail")
                        )
                
    except Exception as e:
        xbmcgui.Dialog().ok("Errore Premium", f"Impossibile caricare i canali Premium: {str(e)}")
        
    xbmcplugin.endOfDirectory(HANDLE)

def list_premium_cinema():
    """Show Cinema, Intrattenimento, and Bambini channels"""
    import requests
    xbmcplugin.setContent(HANDLE, 'videos')
    url = f"{PREMIUM_URL}?numTest=A1A260"
    headers = {"User-Agent": PREMIUM_UA}
    
    try:
        r = requests.get(url, headers=headers, timeout=10)
        data = r.json()
        sections = data.get("channels", [])
        
        for sec in sections:
            name = sec.get("name", "Unknown Group")
            # Show everything EXCEPT Sport (Cinema, Intrattenimento, Bambini)
            if "SPORT" not in name.upper():
                 add_directory_item(name, {"action": "list_premium_category", "cat_data": json.dumps(sec)})
                
    except Exception as e:
        xbmcgui.Dialog().ok("Errore Premium", f"Impossibile caricare i canali Premium: {str(e)}")
        
    xbmcplugin.endOfDirectory(HANDLE)

def list_premium_category(cat_data):
    sec = json.loads(cat_data)
    items = sec.get("items", [])
    
    for it in items:
        # Mandrakodi uses 'myresolve' with protection key
        resolve_val = it.get("myresolve", "")
        if PROTECTION_KEY in resolve_val:
            payload = resolve_val.split("@@")[1]
            title = it.get("title", "Canale")
            add_directory_item(
                title, 
                {"action": "play_premium", "payload": payload, "title": title},
                is_folder=False,
                is_playable=True,
                icon=it.get("thumbnail")
            )
            
    xbmcplugin.endOfDirectory(HANDLE)

def play_premium(payload, title):
    import base64
    
    # Fix padding for base64
    missing_padding = len(payload) % 4
    if missing_padding:
        payload += '=' * (4 - missing_padding)
        
    try:
        decoded = base64.b64decode(payload).decode('utf-8')
        parts = decoded.split('|')
        
        stream_url = parts[0]
        clearkey = parts[1] if len(parts) > 1 else None
        
        # NowTV/Sky uses these headers
        ua = "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/119.0.0.0 Safari/537.36"
        host = "https://www.nowtv.it"
        headers = f"User-Agent={ua}&Referer={host}/&Origin={host}&verifypeer=false"
        
        list_item = xbmcgui.ListItem(path=stream_url)
        list_item.setInfo('video', {'title': title})
        
        # Set InputStream Adaptive properties
        list_item.setProperty('inputstream', 'inputstream.adaptive')
        if ".mpd" in stream_url:
            list_item.setProperty('inputstream.adaptive.file_type', 'mpd')
            list_item.setMimeType("application/dash+xml")
        elif ".m3u8" in stream_url:
            list_item.setProperty('inputstream.adaptive.file_type', 'hls')
            list_item.setMimeType("application/x-mpegURL")
            
        if clearkey and clearkey != "0000":
            list_item.setProperty('inputstream.adaptive.drm_legacy', f'org.w3.clearkey|{clearkey}')
            
        list_item.setProperty('inputstream.adaptive.stream_headers', headers)
        list_item.setProperty('inputstream.adaptive.manifest_headers', headers)
        
        xbmcplugin.setResolvedUrl(HANDLE, True, listitem=list_item)
        
    except Exception as e:
        xbmcgui.Dialog().notification("Errore Play", f"Errore decodifica: {str(e)}", xbmcgui.NOTIFICATION_ERROR)

# --- FREESHOT (SKY SPORT LIVE) ---

def list_freeshot():
    """Lista canali Sky Sport via Freeshot (da config remota)"""
    xbmcplugin.setContent(HANDLE, 'videos')
    
    cfg = get_remote_config()
    channels = cfg.get("freeshot", {}).get("channels", [])
    
    for ch in channels:
        add_directory_item(
            ch["name"],
            {"action": "play_freeshot", "code": ch["code"], "title": ch["name"]},
            is_folder=False,
            is_playable=True
        )
        
    xbmcplugin.endOfDirectory(HANDLE)

def play_freeshot(code, title):
    """Risolvi e riproduci un canale Freeshot (endpoint da config remota)"""
    import requests
    
    try:
        cfg = get_remote_config().get("freeshot", {})
        player_base = cfg.get("player_base_url", "https://popcdn.day/player/")
        stream_base = cfg.get("stream_base_url", "https://planetary.lovecdn.ru/")
        stream_path = cfg.get("stream_path", "/tracks-v1a1/mono.m3u8")
        referer = cfg.get("referer", "https://thisnot.business/")
        token_regex = cfg.get("token_regex", 'currentToken: "([^"]+)"')
        
        xbmc.log(f"[CBTV] Freeshot: risolvendo {title} ({code})", xbmc.LOGINFO)
        
        ua = "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/135.0.0.0 Safari/537.36 OPR/120.0.0.0"
        
        # Step 1: Ottieni il token
        s = requests.Session()
        headers = {'User-Agent': ua, 'Referer': referer}
        page_url = f"{player_base}{code}"
        
        r = s.get(page_url, headers=headers, timeout=10)
        
        match = re.search(token_regex, r.text)
        if not match:
            raise Exception(f"Token non trovato per {code}")
            
        token = match.group(1)
        xbmc.log(f"[CBTV] Freeshot token ottenuto: {token[:30]}...", xbmc.LOGINFO)
        
        # Step 2: Costruisci URL stream
        stream_url = f"{stream_base}{code}{stream_path}?token={token}"
        xbmc.log(f"[CBTV] Freeshot stream: {stream_url}", xbmc.LOGINFO)
        
        # Step 3: Play con inputstream.ffmpegdirect
        list_item = xbmcgui.ListItem(path=stream_url)
        list_item.setInfo('video', {'title': title})
        list_item.setProperty('inputstream', 'inputstream.ffmpegdirect')
        list_item.setProperty('inputstream.ffmpegdirect.is_realtime_stream', 'true')
        list_item.setProperty('inputstream.ffmpegdirect.manifest_type', 'hls')
        list_item.setMimeType('application/x-mpegURL')
        list_item.setContentLookup(False)
        
        xbmcplugin.setResolvedUrl(HANDLE, True, listitem=list_item)
        
    except Exception as e:
        xbmc.log(f"[CBTV] Errore Freeshot: {str(e)}", xbmc.LOGERROR)
        xbmcgui.Dialog().notification("Errore Freeshot", str(e), xbmcgui.NOTIFICATION_ERROR)
        xbmcplugin.setResolvedUrl(HANDLE, False, xbmcgui.ListItem())

# --- MEDIAHOSTING (SKY SPORT 2 - Backup) ---

def list_mediahosting():
    """Lista canali Sky Sport via Mediahosting (da config remota)"""
    xbmcplugin.setContent(HANDLE, 'videos')
    
    cfg = get_remote_config()
    channels = cfg.get("mediahosting", {}).get("channels", [])
    
    for ch in channels:
        add_directory_item(
            ch["name"],
            {"action": "play_mediahosting", "code": ch["code"], "title": ch["name"]},
            is_folder=False,
            is_playable=True
        )
        
    xbmcplugin.endOfDirectory(HANDLE)

def play_mediahosting(code, title):
    """Risolvi e riproduci un canale Mediahosting (endpoint da config remota)"""
    import requests
    
    try:
        cfg = get_remote_config().get("mediahosting", {})
        embed_base = cfg.get("embed_base_url", "https://mediahosting.space/embed/player?stream=")
        referer = cfg.get("referer", "https://mediahosting.space/")
        source_regex = cfg.get("source_regex", '<source src="(.*?)"')
        
        xbmc.log(f"[CBTV] Mediahosting: risolvendo {title} (stream {code})", xbmc.LOGINFO)
        
        # Step 1: Ottieni URL stream dalla pagina embed
        player_url = f"{embed_base}{code}"
        headers = {'Referer': referer}
        
        r = requests.get(player_url, headers=headers, timeout=15)
        
        match = re.search(source_regex, r.text)
        if not match:
            raise Exception(f"Stream URL non trovato per stream {code}")
            
        stream_url = match.group(1)
        xbmc.log(f"[CBTV] Mediahosting stream: {stream_url}", xbmc.LOGINFO)
        
        # Step 2: Play diretto (URL HLS standard .m3u8)
        list_item = xbmcgui.ListItem(path=stream_url)
        list_item.setInfo('video', {'title': title})
        list_item.setProperty('inputstream', 'inputstream.ffmpegdirect')
        list_item.setProperty('inputstream.ffmpegdirect.is_realtime_stream', 'true')
        list_item.setProperty('inputstream.ffmpegdirect.manifest_type', 'hls')
        list_item.setMimeType('application/x-mpegURL')
        list_item.setContentLookup(False)
        
        xbmcplugin.setResolvedUrl(HANDLE, True, listitem=list_item)
        
    except Exception as e:
        xbmc.log(f"[CBTV] Errore Mediahosting: {str(e)}", xbmc.LOGERROR)
        xbmcgui.Dialog().notification("Errore Mediahosting", str(e), xbmcgui.NOTIFICATION_ERROR)
        xbmcplugin.setResolvedUrl(HANDLE, False, xbmcgui.ListItem())

# --- AGENDA (SCRAPER) ---

def list_agenda():
    events = get_oasport_events()
    if not events:
        xbmcgui.Dialog().notification("Agenda", "No events found today", xbmcgui.NOTIFICATION_INFO)
        xbmcplugin.endOfDirectory(HANDLE)
        return
    
    # User preferred sports: keep 'calcio' to catch all soccer, then filter by league/exclusion
    requested_sports = ["calcio", "tennis", "volley", "pallavolo", "f1", "motor", "motogp"]
    
    # Explicitly exclude these to clean up the agenda
    excluded_keywords = [
        "ciclismo", "scialpinismo", "sci alpino", "biathlon", "rugby", "basket", 
        "atletica", "nuoto", "pallaman", "pallanuoto", "calcio a 5", "futsal",
        "serie b", "serie c", "lega pro", "calcio femminile"
    ]
    
    # Strictly soccer leagues requested by the user + major ones
    important_leagues = [
        "serie a", "la liga", "premier league", "champions league", "europa league", 
        "laliga", "bundesliga", "ligue 1", "league 1", "eredivisie", "liga", "premier"
    ]

    items_added = 0
    # Use a set to prevent showing the exact same event multiple times
    seen_events = set()
    
    for ev in events:
        sport_lower = ev['sport'].lower()
        title_lower = ev['title'].lower()
        event_key = f"{ev['time']}_{ev['sport']}_{ev['title']}"
        
        if event_key in seen_events: continue

        # 1. Check if it's an excluded sport or specifically excluded soccer league
        if any(ex in sport_lower or ex in title_lower for ex in excluded_keywords):
            continue
            
        # 2. Check if it's a requested sport
        is_requested_sport = any(req in sport_lower for req in requested_sports)
        
        # 3. Check if it's one of the requested SOCCER leagues (extra safety)
        is_important_soccer = any(league in title_lower or league in sport_lower for league in important_leagues)
        
        # Special case: F1/MotoGP might be in title
        is_motor_title = any(req in title_lower for req in ["f1", "motogp"])

        # Inclusion logic: 
        # - If it's Calcio, it MUST be an important league
        # - If it's other requested sports, show them
        show_event = False
        if "calcio" in sport_lower:
            if is_important_soccer:
                show_event = True
        elif is_requested_sport or is_motor_title:
            show_event = True

        if show_event:
            title = f"{ev['time']} | {ev['sport']}: {ev['title']}"
            add_directory_item(title, {"action": "resolve_agenda_event", "event_data": json.dumps(ev)}, is_folder=True)
            items_added += 1
            seen_events.add(event_key)
            
    xbmcplugin.endOfDirectory(HANDLE)

def resolve_agenda_event(event_data):
    ev = json.loads(event_data)
    
    # --- 1. PREMIUM CHANNELS FETCH & MATCH ---
    try:
        import requests
        channels_raw = ev.get('channels_raw', [])
        
        # Fix: if channels_raw is a string, wrap it in a list
        if isinstance(channels_raw, str):
            channels_raw = [channels_raw]
        
        required_channels = [c.lower().strip() for c in channels_raw if c]
        
        url = f"{PREMIUM_URL}?numTest=A1A260"
        headers = {"User-Agent": PREMIUM_UA}
        r = requests.get(url, headers=headers, timeout=5)
        data = r.json()
        
        match_count = 0
        
        for sec in data.get("channels", []):
            # WHITELIST: Mostra SOLO le sezioni SPORT (invece di blacklist)
            section_name = sec.get("name", "").upper()
            if "SPORT" not in section_name:
                continue  # Salta tutto ciò che non ha "SPORT" nel nome
                
            for p_item in sec.get("items", []):
                p_title = p_item.get("title", "")
                
                # CLEAN PRO: Via TUTTI i tag [COLOR...] e simili con regex
                p_title_clean = re.sub(r'\[.*?\]', '', p_title).strip().lower()
                
                
                # --- MATCHING LOGIV (SMART SPORT FILTER) ---
                is_match = False
                
                # 1. STRICT MATCH (Se il nome è EXACTLY quello richiesto)
                for req in required_channels:
                    req_words = req.split()
                    title_words = p_title_clean.split()
                    if all(word in title_words for word in req_words):
                         is_match = True
                         break
                
                # 2. CONTEXT FALLBACK (Se non c'è match esatto, usa la logica dello sport)
                if not is_match:
                    sport_type = ev.get('sport', '').lower()
                    
                    # ESCLUSIONE GLOBALE: Sport 24 è un TG, non una partita
                    if "sport 24" in p_title_clean:
                        continue
                    
                    # LOGICA CALCIO
                    if "calcio" in sport_type or "serie" in sport_type or "champions" in sport_type:
                        # Includi canali calcistici probabili
                        if any(k in p_title_clean for k in ["calcio", "sport uno", "dazn", "sport 1", "sport 25", "sport 2", "diretta"]):
                            is_match = True
                        # MA escludi categoricamente altri sport
                        if any(k in p_title_clean for k in ["tennis", "basket", "f1", "motogp", "golf", "rugby", "cricket", "nba", "volley"]):
                            is_match = False
                            
                    # LOGICA MOTORI
                    elif "motor" in sport_type or "f1" in sport_type or "moto" in sport_type:
                        # MUST have motor keywords
                        if any(k in p_title_clean for k in ["f1", "motogp", "motor", "race", "sport 1", "sport 2"]):
                             is_match = True
                        
                        # BUT exclude obvious mismatches
                        if any(k in p_title_clean for k in ["calcio", "basket", "tennis", "golf", "rugby", "cricket"]):
                            is_match = False
                        # Specific exclusions for common false positives
                        if "sport 24" in p_title_clean or "sport arena" in p_title_clean:
                             is_match = False

                    # LOGICA TENNIS    
                    elif "tennis" in sport_type:
                        if any(k in p_title_clean for k in ["tennis", "eurosport", "sport uno", "supertennis"]):
                            is_match = True
                        if any(k in p_title_clean for k in ["calcio", "motogp", "f1", "basket", "sport 24", "sport arena"]):
                            is_match = False
                            
                    # LOGICA BASKET & VOLLEY
                    elif "basket" in sport_type or "volley" in sport_type:
                         if any(k in p_title_clean for k in ["basket", "nba", "euroleague", "volley", "pallavolo", "rai sport"]):
                            is_match = True
                         if any(k in p_title_clean for k in ["calcio", "tennis", "motor", "f1", "sport 24"]):
                            is_match = False
                            
                    # FALLBACK GENERICO (Se non è uno sport specifico sopra, e.g. Darts, Snooker)
                    else:
                        # Mostra tutto ciò che è Sport generico
                        if "sport" in p_title_clean:
                             is_match = True
                        # Ma Pulisci comunque
                        if any(k in p_title_clean for k in ["calcio", "tennis", "basket", "f1", "motogp"]):
                             is_match = False

                
                if is_match:
                    resolve_val = p_item.get("myresolve", "")
                    if PROTECTION_KEY in resolve_val:
                        payload = resolve_val.split("@@")[1]
                        # Remove color tags for display
                        display_name = re.sub(r'\[.*?\]', '', p_title).strip()
                        display_title = f"[COLOR gold][PREMIUM][/COLOR] {display_name}"
                        
                        add_directory_item(
                            display_title, 
                            {"action": "play_premium", "payload": payload, "title": display_title},
                            is_folder=False,
                            is_playable=True,
                            icon=p_item.get("thumbnail")
                        )
                        match_count += 1

        if match_count == 0:
             xbmcgui.Dialog().notification("Agenda", "Nessun canale Premium trovato per questo evento", xbmcgui.NOTIFICATION_INFO)

    except Exception as e:
        # Silently fail on premium fetch
        pass
    
    # --- 2. MPD NAZIONI CHANNELS FETCH & MATCH ---
    try:
        import requests
        channels_raw = ev.get('channels_raw', [])
        if isinstance(channels_raw, str):
            channels_raw = [channels_raw]
        required_channels = [c.lower().strip() for c in channels_raw if c]
        
        # Fetch MPD Nazioni
        headers = {"User-Agent": MPD_UA}
        r_mpd = requests.get(MPD_NAZIONI_URL, headers=headers, timeout=10)
        data_mpd = r_mpd.json()
        countries = data_mpd.get("channels", [])
        
        mpd_match_count = 0
        
        # Search through all countries for matching channels
        for country in countries:
            country_name = re.sub(r'\[.*?\]', '', country.get("name", "")).strip()
            items = country.get("items", [])
            
            for ch in items:
                ch_title = ch.get("title", "")
                ch_title_clean = re.sub(r'\[.*?\]', '', ch_title).strip().lower()
                myresolve = ch.get("myresolve", "")
                
                # Check if this MPD channel matches required channels
                if myresolve and "@@" in myresolve:
                    is_match = False
                    
                    # Exact or partial match with required channels
                    for req in required_channels:
                        req_words = req.split()
                        if all(word in ch_title_clean for word in req_words):
                            is_match = True
                            break
                    
                    # Sport-specific matching (like Premium logic)
                    if not is_match:
                        sport_type = ev.get('sport', '').lower()
                        
                        # Exclude Sport 24 (it's news, not matches)
                        if "sport 24" in ch_title_clean:
                            continue
                        
                        # CALCIO logic
                        if "calcio" in sport_type or "serie" in sport_type or "champions" in sport_type:
                            if any(k in ch_title_clean for k in [
                                "calcio", "sport uno", "sport 1", "sport 2", "sport 3",
                                "bt sport", "bein", "sky sport", "dazn", "tnt sports",
                                "tsn", "canal+", "laliga", "premier", "football"
                            ]):
                                is_match = True
                            # Exclude other sports
                            if any(k in ch_title_clean for k in ["tennis", "basket", "f1", "motogp", "golf", "volley"]):
                                is_match = False
                        
                        # MOTORS (F1/MotoGP) logic
                        elif "motor" in sport_type or "f1" in sport_type or "moto" in sport_type:
                            if any(k in ch_title_clean for k in [
                                "f1", "motogp", "motor", "race", "sport 1", "sport 2",
                                "sky sport f1", "dazn f1", "movistar f1", "viaplay motor"
                            ]):
                                is_match = True
                            if any(k in ch_title_clean for k in ["calcio", "tennis", "basket", "sport 24", "football"]):
                                is_match = False
                        
                        # TENNIS logic - EXPANDED FOR INTERNATIONAL CHANNELS
                        elif "tennis" in sport_type:
                            if any(k in ch_title_clean for k in [
                                "tennis", "eurosport", "supertennis", "tennis channel",
                                "sport tv", "tsn", "espn", "bein sport", "sky sport",
                                "polsat sport", "sport 1", "sport 2", "arena sport"
                            ]):
                                is_match = True
                            # Exclude obvious mismatches
                            if any(k in ch_title_clean for k in ["calcio", "f1", "motogp", "sport 24", "football"]):
                                is_match = False
                        
                        # VOLLEY/BASKET logic - EXPANDED FOR INTERNATIONAL CHANNELS
                        elif "basket" in sport_type or "volley" in sport_type or "pallavolo" in sport_type:
                            if any(k in ch_title_clean for k in [
                                "volley", "pallavolo", "basket", "nba", "euroleague",
                                "rai sport", "eurosport", "polsat sport", "sky sport arena",
                                "sport tv", "arena sport", "dazn", "sport 1", "sport 2"
                            ]):
                                is_match = True
                            if any(k in ch_title_clean for k in ["calcio", "tennis", "f1", "motogp", "sport 24", "football"]):
                                is_match = False
                        
                        # GENERIC SPORT (other sports like rugby, golf, etc.)
                        else:
                            # For other sports, be more inclusive with international sports channels
                            if any(k in ch_title_clean for k in [
                                "eurosport", "sport tv", "tsn", "espn", "bein sport",
                                "arena sport", "sky sport", "polsat sport"
                            ]):
                                is_match = True
                            # But still exclude obviously wrong ones
                            if any(k in ch_title_clean for k in ["sport 24"]):
                                is_match = False
                    
                    if is_match:
                        display_name = re.sub(r'\[.*?\]', '', ch_title).strip()
                        display_title = f"[COLOR cyan][MPD - {country_name}][/COLOR] {display_name}"
                        
                        add_directory_item(
                            display_title,
                            {"action": "show_mpd_play", "resolve_data": myresolve, "channel_name": display_name},
                            is_folder=True,
                            is_playable=False,
                            icon=ch.get("thumbnail")
                        )
                        mpd_match_count += 1
        
    except Exception as e:
        # Silently fail on MPD fetch
        pass
        
    xbmcplugin.endOfDirectory(HANDLE)

# --- MPD NAZIONI (MANDRAKODI SPORT SOURCE) ---

MPD_NAZIONI_URL = "https://test34344.herokuapp.com/filter.php?numTest=A1A134A"
MPD_UA = "MandraKodi2@@1.2.78@@MandraKodi3@@S63TDC"

def list_mpd_nazioni():
    """Show list of countries from MPD Nazioni"""
    import requests
    xbmcplugin.setContent(HANDLE, 'videos')
    
    try:
        headers = {"User-Agent": MPD_UA}
        r = requests.get(MPD_NAZIONI_URL, headers=headers, timeout=10)
        data = r.json()
        countries = data.get("channels", [])
        
        for country in countries:
            name = country.get("name", "Unknown")
            # Clean color tags for display
            clean_name = re.sub(r'\[.*?\]', '', name).strip()
            thumb = country.get("thumbnail")
            
            add_directory_item(
                clean_name,
                {"action": "list_mpd_channels", "country_data": json.dumps(country)},
                icon=thumb
            )
    except Exception as e:
        xbmcgui.Dialog().notification("MPD Nazioni", f"Errore: {str(e)}", xbmcgui.NOTIFICATION_ERROR)
    
    xbmcplugin.endOfDirectory(HANDLE)

def list_mpd_channels(country_data):
    """Show channels for selected country"""
    import requests
    xbmcplugin.setContent(HANDLE, 'videos')
    
    try:
        country = json.loads(country_data)
        items = country.get("items", [])
        
        for ch in items:
            title = ch.get("title", "No Title")
            # Clean color tags
            clean_title = re.sub(r'\[.*?\]', '', title).strip()
            thumb = ch.get("thumbnail")
            myresolve = ch.get("myresolve", "")
            
            # Check if this is an MPD channel (has amstaff@@ prefix)
            if myresolve and "@@" in myresolve:
                # Make it a FOLDER that opens a submenu (like Mandrakodi)
                add_directory_item(
                    f"[COLOR cyan]{clean_title}[/COLOR]",
                    {"action": "show_mpd_play", "resolve_data": myresolve, "channel_name": clean_title},
                    is_folder=True,  # Changed to True - opens submenu
                    is_playable=False,
                    icon=thumb
                )
    except Exception as e:
        xbmcgui.Dialog().notification("MPD Canali", f"Errore: {str(e)}", xbmcgui.NOTIFICATION_ERROR)
    
    xbmcplugin.endOfDirectory(HANDLE)

def show_mpd_play(resolve_data, channel_name):
    """Show 'PLAY STREAM' option for the selected channel (Mandrakodi-style)"""
    xbmcplugin.setContent(HANDLE, 'videos')
    
    try:
        # Extract payload after @@
        payload = resolve_data.split("@@")[1]
        
        # Check if payload is a direct URL or Base64-encoded
        if payload.startswith("http://") or payload.startswith("https://"):
            # Direct URL format (e.g., RAI Sport)
            # Format: https://example.com/stream.mpd|0000 or |KID:KEY
            parts = payload.split("|")
            stream_url = parts[0]
            license_data = parts[1] if len(parts) > 1 else ""
        else:
            # Base64-encoded format (most channels)
            # Add padding if needed
            missing_padding = len(payload) % 4
            if missing_padding:
                payload += '=' * (4 - missing_padding)
            
            # Decode Base64
            decoded = base64.b64decode(payload).decode('utf-8')
            parts = decoded.split("|")
            stream_url = parts[0]
            license_data = parts[1] if len(parts) > 1 else ""
        
        # Create ListItem with path already set (like Mandrakodi)
        list_item = xbmcgui.ListItem(label="[COLOR lime]PLAY STREAM[/COLOR]", path=stream_url, offscreen=True)
        list_item.setInfo('video', {'title': channel_name})
        list_item.setProperty('IsPlayable', 'true')
        list_item.setContentLookup(False)
        
        # Set inputstream.adaptive
        list_item.setProperty('inputstream', 'inputstream.adaptive')
        
        # Set MIME type for MPD
        if ".mpd" in stream_url:
            list_item.setMimeType("application/dash+xml")
        
        # Set Clearkey DRM using drm_legacy (like Mandrakodi does!)
        # Note: license_data="0000" means no DRM (unencrypted stream)
        if license_data and ":" in license_data and license_data != "0000":
            drm_type = "org.w3.clearkey"
            # Format: org.w3.clearkey|KID:KEY
            list_item.setProperty('inputstream.adaptive.drm_legacy', f"{drm_type}|{license_data}")
        
        # Add as directory item
        xbmcplugin.addDirectoryItem(
            handle=HANDLE,
            url=stream_url,
            listitem=list_item,
            isFolder=False
        )
        
    except Exception as e:
        xbmcgui.Dialog().notification("MPD Play", f"Errore: {str(e)}", xbmcgui.NOTIFICATION_ERROR)
    
    xbmcplugin.endOfDirectory(HANDLE)

def play_mpd(resolve_data):
    """Decode and play MPD stream with Clearkey DRM"""
    try:
        # Extract payload after @@
        payload = resolve_data.split("@@")[1]
        
        # Check if payload is a direct URL or Base64-encoded
        if payload.startswith("http://") or payload.startswith("https://"):
            # Direct URL format (e.g., RAI Sport)
            parts = payload.split("|")
            stream_url = parts[0]
            license_data = parts[1] if len(parts) > 1 else ""
        else:
            # Base64-encoded format (most channels)
            # Add padding if needed
            missing_padding = len(payload) % 4
            if missing_padding:
                payload += '=' * (4 - missing_padding)
            
            # Decode Base64
            decoded = base64.b64decode(payload).decode('utf-8')
            
            # Parse URL|KID:KEY format
            parts = decoded.split("|")
            stream_url = parts[0]
            license_data = parts[1] if len(parts) > 1 else ""
        
        # Create ListItem for playback
        list_item = xbmcgui.ListItem(path=stream_url)
        
        # Set inputstream.adaptive for MPD playback
        list_item.setProperty('inputstream', 'inputstream.adaptive')
        list_item.setProperty('inputstream.adaptive.manifest_type', 'mpd')
        
        # Set Clearkey DRM if license key is provided
        # Note: license_data="0000" means no DRM (unencrypted stream)
        if license_data and ":" in license_data and license_data != "0000":
            # Split KID:KEY
            kid_key = license_data.split(":")
            kid = kid_key[0]
            key = kid_key[1]
            
            # Clearkey format for inputstream.adaptive
            # Some versions want JSON, others accept KID:KEY directly
            # Try the simple format first
            list_item.setProperty('inputstream.adaptive.license_type', 'clearkey')
            list_item.setProperty('inputstream.adaptive.license_key', license_data)
            
            # Alternative: Try JSON format (commented out for now)
            # clearkey_json = json.dumps({
            #     "keys": [{
            #         "kty": "oct",
            #         "kid": kid,
            #         "k": key
            #     }]
            # })
            # list_item.setProperty('inputstream.adaptive.license_key', clearkey_json)
        
        xbmcplugin.setResolvedUrl(HANDLE, True, list_item)
        
    except Exception as e:
        xbmcgui.Dialog().notification("Play MPD", f"Errore: {str(e)}", xbmcgui.NOTIFICATION_ERROR)
        xbmcplugin.setResolvedUrl(HANDLE, False, xbmcgui.ListItem())

if __name__ == '__main__':
    params = dict(parse_qsl(sys.argv[2][1:]))
    action = params.get('action')
    if not action: main_menu()
    elif action == 'list_agenda': list_agenda()
    elif action == 'list_sport': list_sport()
    elif action == 'list_sport_sky': list_sport_sky()
    elif action == 'resolve_agenda_event': resolve_agenda_event(params.get('event_data'))
    elif action == 'list_premium_sport': list_premium_sport()
    elif action == 'list_premium_cinema': list_premium_cinema()
    elif action == 'list_premium_category': list_premium_category(params.get('cat_data'))
    elif action == 'play_premium': play_premium(params.get('payload'), params.get('title'))
    elif action == 'list_mpd_nazioni': list_mpd_nazioni()
    elif action == 'list_mpd_channels': list_mpd_channels(params.get('country_data'))
    elif action == 'show_mpd_play': show_mpd_play(params.get('resolve_data'), params.get('channel_name'))
    elif action == 'play_mpd': play_mpd(params.get('resolve_data'))
    elif action == 'list_freeshot': list_freeshot()
    elif action == 'play_freeshot': play_freeshot(params.get('code'), params.get('title'))
    elif action == 'list_mediahosting': list_mediahosting()
    elif action == 'play_mediahosting': play_mediahosting(params.get('code'), params.get('title'))
    elif action == 'resolve_match_menu': resolve_match_menu(params.get('match_data'))
    elif action == 'resolve_menu': resolve_menu(params.get('url'), params.get('title'))
    elif action == 'play_internal': play_internal(params.get('url'), params.get('title'))
