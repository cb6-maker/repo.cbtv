import requests
import re
import xbmc
import os
import json
import time
import xbmcaddon
import xbmcvfs
import concurrent.futures

# --- CONFIGURAZIONE SORGENTE EB ---
PORTAL_URL = "http://bulut001.com:8080/c/"
MAC_ADDRESS = "00:1A:79:10:DF:F6"

def clean_text(text):
    """Rimuove simboli speciali ed emoticon preservando i nomi commerciali (Sky, Fox, etc.)"""
    if not text: return ""
    # 1. Rimuove emoticon e simboli grafici (stille, cuori, pallini, etc.) preservando lettere, numeri e punteggiatura base
    cleaned = "".join(c for c in text if ord(c) < 128 or c in "àèìòùÀÈÌÒÙ")
    
    # 2. Rimuove prefissi regionali noti (IT, PL, BG, ecc.) solo se separati da simboli tipo | o - o spazi all'inizio
    # Esempi: "IT | Sky Uno" -> "Sky Uno", "IT Sky Uno" -> "Sky Uno"
    cleaned = re.sub(r'^[A-Z]{2,3}\s*[\-\|]\s*', '', cleaned)
    cleaned = re.sub(r'^[A-Z]{2,2}\s+(?=[A-Z])', '', cleaned) # "IT SKY" -> "SKY" be careful
    
    # Sostituiamo FHD con HD per favorire il matching EPG
    cleaned = cleaned.replace("FHD", "HD").replace("fhd", "hd")
    
    # Rimuoviamo eventuali doppie spaziature
    return cleaned.replace('  ', ' ').strip()

class EagleStalkerClient:
    def __init__(self, portal=PORTAL_URL, mac=MAC_ADDRESS):
        self.portal = portal
        self.mac = mac
        self.headers = {
            'User-Agent': 'Mozilla/5.0 (QtEmbedded; U; Linux; C) AppleWebKit/533.3 (KHTML, like Gecko) MAG200 stbapp ver: 2 rev: 250 Safari/533.3',
            'X-User-Agent': 'Model: MAG250; Link: WiFi',
            'Referer': self.portal,
            'Cookie': f'mac={self.mac}'
        }
        # Path della cache
        addon = xbmcaddon.Addon()
        profile = xbmcvfs.translatePath(addon.getAddonInfo('profile'))
        if not os.path.exists(profile):
            os.makedirs(profile)
        self.cache_dir = profile

    def _get_cache(self, key):
        """Recupera dati dalla cache se validi (12 ore)"""
        cache_file = os.path.join(self.cache_dir, f"eb_cache_{key}.json")
        if os.path.exists(cache_file):
            try:
                with open(cache_file, 'r', encoding='utf-8') as f:
                    data = json.load(f)
                    if time.time() - data.get('timestamp', 0) < 43200: # 12 ore
                        return data.get('content')
            except: pass
        return None

    def _set_cache(self, key, content):
        """Salva dati in cache"""
        cache_file = os.path.join(self.cache_dir, f"eb_cache_{key}.json")
        try:
            with open(cache_file, 'w', encoding='utf-8') as f:
                json.dump({'timestamp': time.time(), 'content': content}, f)
        except: pass

    def _call(self, action, params=None):
        if params is None: params = {}
        params.update({'type': 'itv', 'action': action, 'js': '1'})
        try:
            r = requests.get(f"{self.portal}portal.php", headers=self.headers, params=params, timeout=15)
            if r.status_code == 200:
                res = r.json()
                return res.get('js', {})
            return {}
        except Exception:
            return {}

    def get_categories(self, force_refresh=False):
        """Ritorna tutte le categorie del portale (con cache)"""
        if not force_refresh:
            cached = self._get_cache("categories")
            if cached: return cached
        
        res = self._call("get_genres")
        if res:
            self._set_cache("categories", res)
        return res

    def get_channels_by_genre(self, genre_id, page=1):
        """Ritorna i canali di una specifica categoria"""
        params = {'action': 'get_ordered_list', 'genre': genre_id, 'p': str(page)}
        return self._call("get_ordered_list", params)

    def generate_stream_link(self, cmd):
        """Converte il comando del canale in un URL di streaming reale"""
        params = {'action': 'create_link', 'cmd': cmd}
        res = self._call("create_link", params)
        url = res.get('cmd', '')
        if " " in url:
            return url.split(" ")[1]
        return url

    def get_sky_tv_channels(self, force_refresh=False):
        """Recupera TUTTI i canali Sky (con cache)"""
        cache_key = "sky_tv_v3"
        if not force_refresh:
            cached = self._get_cache(cache_key)
            if cached: return cached

        # Rimosso FOX e CRIME per specifica richiesta user
        keywords = ["SKY ", "ATLANTIC", "SERIE", "LIFE", "COMEDY", "ACTION", "DRAMA", "FAMILY", "ROMANCE", "SUSPENSE", "COLLECTION"]
        it_genres = [g for g in self.get_categories(force_refresh=force_refresh) if any(k in g.get('title','').upper() for k in ["IT ", "ITALIA"])]
        
        def fetch_page(genre, page):
            res = self.get_channels_by_genre(genre['id'], page)
            if res and 'data' in res and res['data']:
                return res['data'], genre
            return [], genre

        # Prepariamo i task per il ThreadPool
        tasks = []
        for g in it_genres:
            g_title = g.get('title','').upper()
            if "SPORT" in g_title or "DAZN" in g_title:
                continue
            for p in range(1, 16):
                tasks.append((g, p))

        found = []
        with concurrent.futures.ThreadPoolExecutor(max_workers=10) as executor:
            future_to_page = {executor.submit(fetch_page, g, p): (g, p) for g, p in tasks}
            for future in concurrent.futures.as_completed(future_to_page):
                data, genre = future.result()
                if data:
                    for ch in data:
                        name_raw = ch.get('name', '')
                        name_up = name_raw.upper()
                        # Filtro negativo potenziato (rimossi Rai, Mediaset, Fox, Top Crime, Investigation)
                        if any(k in name_up for k in keywords) and not any(x in name_up for x in ["RAI", "ITALIA 1", "RETE 4", "CANALE 5", "LA7", "TV8", "NOVE", "FOX", "CRIME", "INVESTIGATION"]):
                            found.append({
                                'name': clean_text(name_raw),
                                'cmd': ch.get('cmd'),
                                'category': clean_text(genre.get('title'))
                            })
        
        # Ordiniamo per nome per coerenza
        found.sort(key=lambda x: x['name'])
        self._set_cache(cache_key, found)
        return found

    def get_sky_sport_channels(self, force_refresh=False):
        """Recupera i canali Sky Sport Italia da Eagle Black (con cache)"""
        cache_key = "sky_sport_v2"
        if not force_refresh:
            cached = self._get_cache(cache_key)
            if cached: return cached

        # Parole chiave per Sky Sport e Eurosport IT
        keywords = ["SKY SPORT", "EUROSPORT", "ZONA DAZN"]
        it_genres = [g for g in self.get_categories(force_refresh=force_refresh) if any(k in g.get('title','').upper() for k in ["IT ", "ITALIA"])]
        
        def fetch_page(genre, page):
            res = self.get_channels_by_genre(genre['id'], page)
            if res and 'data' in res and res['data']:
                return res['data'], genre
            return [], genre

        tasks = []
        for g in it_genres:
            g_title = g.get('title','').upper()
            if "SPORT" in g_title or "CALCIO" in g_title:
                for p in range(1, 11):
                    tasks.append((g, p))

        found = []
        seen_cmds = set()
        with concurrent.futures.ThreadPoolExecutor(max_workers=10) as executor:
            future_to_page = {executor.submit(fetch_page, g, p): (g, p) for g, p in tasks}
            for future in concurrent.futures.as_completed(future_to_page):
                data, genre = future.result()
                if data:
                    for ch in data:
                        cmd = ch.get('cmd')
                        if cmd in seen_cmds: continue
                        name_raw = ch.get('name', '')
                        name_up = name_raw.upper()
                        # Filtriamo per canali sportivi italiani di Sky
                        if any(k in name_up for k in keywords):
                            found.append({
                                'name': clean_text(name_raw),
                                'cmd': cmd,
                                'category': clean_text(genre.get('title'))
                            })
                            seen_cmds.add(cmd)
        
        found.sort(key=lambda x: x['name'])
        self._set_cache(cache_key, found)
        return found

    def get_dazn_channels(self, force_refresh=False):
        """Recupera DAZN Italiani (con cache)"""
        if not force_refresh:
            cached = self._get_cache("dazn_v2")
            if cached: return cached

        all_genres = self.get_categories(force_refresh=force_refresh)
        dazn_genres = [g for g in all_genres if "DAZN" in g.get('title','').upper() and any(k in g.get('title','').upper() for k in ["IT ", "ITALIA"])]
        
        def fetch_page(genre, page):
            res = self.get_channels_by_genre(genre['id'], page)
            if res and 'data' in res and res['data']:
                return res['data'], genre
            return [], genre

        tasks = []
        for g in dazn_genres:
            for p in range(1, 6):
                tasks.append((g, p))

        found = []
        with concurrent.futures.ThreadPoolExecutor(max_workers=5) as executor:
            future_to_page = {executor.submit(fetch_page, g, p): (g, p) for g, p in tasks}
            for future in concurrent.futures.as_completed(future_to_page):
                data, genre = future.result()
                if data:
                    for ch in data:
                        found.append({
                            'name': clean_text(ch.get('name')),
                            'cmd': ch.get('cmd'),
                            'category': clean_text(genre.get('title'))
                        })

        found.sort(key=lambda x: x['name'])
        self._set_cache("dazn_v2", found)
        return found

    def get_intl_eb_list2(self, force_refresh=False):
        """Ritorna la struttura Sport Polsat, Max Sport, Canal+, Ziggo (con cache)"""
        # Se modifichiamo la logica, forziamo il refresh o usiamo una chiave diversa
        cache_key = "list2_v5" 
        if not force_refresh:
            cached = self._get_cache(cache_key)
            if cached: return cached

        all_genres = self.get_categories(force_refresh=force_refresh)
        itinerary = {
            "Polonia": {"genres": ["PL ", "POLAND"], "keywords": ["POLSAT SPORT"]},
            "Bulgaria": {"genres": ["BG ", "BULGARIA"], "keywords": ["MAX SPORT"]},
            "Olanda": {"genres": ["NL ", "NETHERLANDS"], "keywords": ["ZIGGO SPORT"]}
        }
        
        def fetch_page(genre, page, nation):
            res = self.get_channels_by_genre(genre['id'], page)
            if res and 'data' in res and res['data']:
                return res['data'], genre, nation
            return [], genre, nation

        tasks = []
        final_structure = {n: [] for n in itinerary}
        
        for nation, config in itinerary.items():
            target_genres = [g for g in all_genres if any(k in g.get('title','').upper() for k in config["genres"])]
            for g in target_genres:
                for p in range(1, 6):
                    tasks.append((g, p, nation))

        with concurrent.futures.ThreadPoolExecutor(max_workers=10) as executor:
            future_to_page = {executor.submit(fetch_page, g, p, n): (g, p, n) for g, p, n in tasks}
            for future in concurrent.futures.as_completed(future_to_page):
                data, genre, nation = future.result()
                if data:
                    config = itinerary[nation]
                    for ch in data:
                        name_up = ch.get('name', '').upper()
                        if any(k in name_up for k in config["keywords"]):
                            final_structure[nation].append({
                                'name': clean_text(ch.get('name')),
                                'cmd': ch.get('cmd'),
                                'category': clean_text(genre.get('title'))
                            })

        # Ordiniamo per nazione e poi per nome
        for n in final_structure:
            final_structure[n].sort(key=lambda x: x['name'])
            
        self._set_cache(cache_key, final_structure)
        return final_structure
