import requests
import re
import json
import xbmc
from urllib.parse import unquote, quote_plus

class CDNLiveResolver:
    def __init__(self, user="streamsports99", plan="vip"):
        self.user = user
        self.plan = plan
        self.base_api = "https://api.cdn-live.tv/api/v1"
        self.player_referer = "https://streamsports99.su/"
        self.ua = "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/121.0.0.0 Safari/537.36"
        self.last_error = None

    def get_headers(self, referer=None):
        return {
            "User-Agent": self.ua,
            "Referer": referer if referer else self.player_referer,
            "Origin": "https://cdn-live.tv"
        }

    def fetch_api(self, endpoint):
        url = f"{self.base_api}/{endpoint}/?user={self.user}&plan={self.plan}"
        xbmc.log(f"CDNLive: Fetching API: {url}", xbmc.LOGINFO)
        try:
            r = requests.get(url, headers=self.get_headers(), timeout=15, verify=False)
            xbmc.log(f"CDNLive: API Status: {r.status_code}", xbmc.LOGINFO)
            r.raise_for_status()
            data = r.json()
            return data
        except Exception as e:
            xbmc.log(f"CDNLive: API Error: {str(e)}", xbmc.LOGERROR)
            return None

    def get_channels(self):
        data = self.fetch_api("channels")
        channels = data.get("channels", []) if data else []
        xbmc.log(f"CDNLive: Total channels from API: {len(channels)}", xbmc.LOGINFO)
        
        # Filter for online channels only
        online = [ch for ch in channels if ch.get("status") == "online"]
        xbmc.log(f"CDNLive: Online channels filter: {len(online)}", xbmc.LOGINFO)
        
        # FALLBACK: If filtering for 'online' results in 0, return all channels
        # This prevents an empty menu if the API status field is temporarily unreliable
        if channels and not online:
            xbmc.log("CDNLive: WARNING: Online filter returned 0, falling back to all channels", xbmc.LOGWARNING)
            return channels
            
        return online

    def get_channels_grouped(self):
        channels = self.get_channels()
        grouped = {}
        for ch in channels:
            # Map code (e.g., 'it', 'en', 'es') to country name
            country_code = ch.get("code", "ot").lower()
            country_map = {
                "it": "Italy", "es": "Spain", "en": "UK / International", "us": "USA",
                "fr": "France", "de": "Germany", "pt": "Portugal", "dk": "Denmark",
                "tr": "Turkey", "ro": "Romania", "pl": "Poland", "ar": "Arabic"
            }
            country_name = country_map.get(country_code, "Other")
            if country_name not in grouped: grouped[country_name] = []
            grouped[country_name].append(ch)
        return grouped

    def get_sports_categories(self):
        data = self.fetch_api("events/sports")
        if not data or "cdn-live-tv" not in data:
            return {}
        return data["cdn-live-tv"]

    @staticmethod
    def _convert_base(s, base):
        result = 0
        for i, digit in enumerate(reversed(s)):
            result += int(digit) * (base ** i)
        return result

    def _0xe81c(self, d, e, f):
        # Alphabet standard used by the script
        alphabet = "0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ+/"
        h = alphabet[:e]
        val = 0
        for c, char in enumerate(reversed(d)):
            idx = h.find(char)
            val += idx * (int(e) ** c)
        return val

    def decode_stream_url(self, html):
        import re
        import base64
        from urllib.parse import unquote
        
        # Look for the packed function call pattern
        pattern = r'}\("([^"]+)",(\d+),"([^"]+)",(\d+),(\d+),(\d+)\)\)'
        m = re.search(pattern, html)
        
        if not m:
            self.last_error = "Packer pattern not found"
            return None
            
        payload = m.group(1)
        u = int(m.group(2)) # 32
        n = m.group(3)      # KEY
        t = int(m.group(4)) # 8
        e = int(m.group(5)) # 4 (Base)
        
        decoded = ""
        i = 0
        length = len(payload)
        separator_char = n[e] 
        
        try:
            while i < length:
                s_segment = ""
                while i < length and payload[i] != separator_char:
                    s_segment += payload[i]
                    i += 1
                i += 1 
                
                if not s_segment: continue

                temp_s = list(s_segment)
                for char_idx, char in enumerate(temp_s):
                    n_idx = n.find(char)
                    if n_idx != -1:
                        temp_s[char_idx] = str(n_idx)
                
                s_replaced = "".join(temp_s)
                val = self._0xe81c(s_replaced, e, 10)
                decoded += chr(val - t)
        except Exception as ex:
            xbmc.log(f"CDNLive: Error unpacking JS: {ex}", xbmc.LOGERROR)
            return None
            
        # Layer 2: Extract Base64 constants and concatenate
        try:
            final_js = unquote(decoded)
            matches = re.findall(r"const\s+\w+\s*=\s*['\"]([A-Za-z0-9\-\_+/=]+)['\"]", final_js)
            
            full_content = ""
            for b64_str in matches:
                try:
                    fixed_b64 = b64_str.replace('-', '+').replace('_', '/')
                    while len(fixed_b64) % 4 != 0:
                        fixed_b64 += "="
                    part = base64.b64decode(fixed_b64).decode('utf-8')
                    full_content += part
                except:
                    pass
            
            # Find valid m3u8 link
            url_match = re.search(r'(https?://[^"\s]+\.m3u8\?[^"\s]+)', full_content)
            if url_match:
                final_url = url_match.group(1)
                # Truncate at next http if concatenated
                if "http" in final_url[4:]: 
                     next_http = final_url.find("http", 4)
                     if next_http != -1:
                         final_url = final_url[:next_http]
                xbmc.log(f"CDNLive: Decoded URL from Base64 constants: {final_url}", xbmc.LOGINFO)
                return final_url

            # Fallback: simple token regex
            token_match = re.search(r'["\']([^"\']*index\.m3u8\?token=[^"\']+)["\']', final_js)
            if token_match:
                url_part = token_match.group(1).replace("\\/", "/")
                if url_part.startswith("//"): url_part = "https:" + url_part
                return url_part
                
        except Exception as ex:
             xbmc.log(f"CDNLive: Error parsing unpacked JS: {ex}", xbmc.LOGERROR)

        return None

    def resolve(self, player_url, plan=None):
        """Main resolution logic"""
        current_plan = plan if plan else self.plan
        xbmc.log(f"CDNLive: Resolving {player_url} (Plan: {current_plan})", xbmc.LOGINFO)
        
        # Ensure user/plan params
        url = player_url
        if "user=" not in url:
             delimiter = "&" if "?" in url else "?"
             url += f"{delimiter}user={self.user}"
        if "plan=" not in url:
             delimiter = "&" if "?" in url else "?"
             url += f"{delimiter}plan={current_plan}"
        elif f"plan={self.plan}" in url and current_plan != self.plan:
             url = url.replace(f"plan={self.plan}", f"plan={current_plan}")

        try:
            # FIX: The player domain should NOT have 'api.' prefix for free plan/embedded usage
            # But player_url comes from get_channels which includes it?
            # get_channels returns: https://cdn-live.tv/api/v1/channels/player/... (from test_cdn.py output)
            # So player_url is already correct. BUT if we construct it manually, be careful.
            
            # But wait, step 249 failed with 404 on api.cdn-live.tv.
            # step 258 succeeded with cdn-live.tv.
            # So we must ensure we don't use api. subdomain for player.
            url = url.replace("https://api.cdn-live.tv/", "https://cdn-live.tv/")
            
            r = requests.get(url, headers=self.get_headers(), timeout=15, verify=False)
            r.raise_for_status()
            
            final_url = self.decode_stream_url(r.text)
            
            if not final_url:
                 self.last_error = "Stream URL decode failed"
                 xbmc.log("CDNLive: Stream URL decode failed", xbmc.LOGWARNING)
                 return None
            
            # Append headers for Kodi player (ffmpeg)
            # CRITICAL: Values MUST be URL-encoded because Referer contains '&' which breaks ffmpeg parsing!
            from urllib.parse import quote
            
            # Use the modified 'url' (which is the one we fetched) as referer.
            referer_to_use = url
            
            # Expanded headers for better compatibility (fix 401)
            headers_map = {
                "User-Agent": self.ua,
                "Referer": referer_to_use, 
                "Origin": "https://cdn-live.tv",
                "Accept": "*/*"
            }
            
            # Create header string: Header=Value&Header2=Value...
            headers_str = "&".join([f"{k}={quote(v)}" for k, v in headers_map.items()])
            
            final_url += f"|{headers_str}"
            
            xbmc.log(f"CDNLive: Resolved with headers: {final_url}", xbmc.LOGINFO)
            return final_url

        except Exception as e:
            self.last_error = str(e)
            xbmc.log(f"CDNLive: Resolution Error: {str(e)}", xbmc.LOGERROR)
            return None
