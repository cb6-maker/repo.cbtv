import requests
import re
import datetime

# ─── CONFIG FILTRI ────────────────────────────────────────────────

# Tornei di calcio desiderati (match esatto su Categoria e Torneo)
FOOTBALL_FILTERS = [
    # Italia
    {"category": "italy", "tournament": "serie a"},
    {"category": "italy", "tournament": "serie b"},
    {"category": "italy", "tournament": "coppa italia"},
    
    # Coppe europee
    {"category": "international clubs", "tournament": "champions league"},
    {"category": "international clubs", "tournament": "europa league"},
    {"category": "international clubs", "tournament": "conference league"},
    {"category": "international clubs", "tournament": "super cup"},
    
    # Top campionati europei
    {"category": "england", "tournament": "premier league"},
    {"category": "spain", "tournament": "la liga"},
    {"category": "germany", "tournament": "bundesliga"},
    {"category": "france", "tournament": "ligue 1"},
    
    # Nazionali
    {"category": None, "tournament": "euro 202"},
    {"category": None, "tournament": "world cup"},
    {"category": None, "tournament": "nations league"},
]

# Squadre di volley italiane (femminili e maschili principali + nazionale)
ITALIAN_VOLLEY_TEAMS = [
    "perugia", "civitanova", "trento", "trentino", "modena", "monza", "milano",
    "piacenza", "verona", "padova", "taranto", "cisterna", "ravenna", "latina",
    "cuneo", "castellana", "lube", "vibo valentia",
    "conegliano", "novara", "scandicci", "busto arsizio", "firenze",
    "bergamo", "chieri", "roma", "vallefoglia", "casalmaggiore",
    "italy", "italia"
]

# ─── FUNZIONI CORE ────────────────────────────────────────────────

def _create_session():
    session = requests.Session()
    session.headers.update({
        "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36"
    })
    return session

def _fetch_page_json(session, page_url):
    try:
        resp = session.get(page_url, timeout=15)
        if resp.status_code != 200:
            return None
        m = re.search(r"listAction:\s*'(.*?)'", resp.text)
        if not m:
            return None
        
        # client_tz_offset=%2B0100 -> fuso orario Europa/Roma (+01:00)
        list_url = "https://www.sporteventz.com" + m.group(1) + "&client_tz_offset=%2B0100"
        
        resp_json = session.get(list_url, headers={
            "Accept": "application/json, text/javascript, */*; q=0.01",
            "X-Requested-With": "XMLHttpRequest",
            "Referer": page_url
        }, timeout=15)
        
        if not resp_json.text.strip():
            return {"Records": []}
            
        return resp_json.json()
    except Exception:
        return None

def _parse_record(rec):
    team1 = rec.get('Team1', {}).get('#text', '') if isinstance(rec.get('Team1'), dict) else ''
    team2 = rec.get('Team2', {}).get('#text', '') if isinstance(rec.get('Team2'), dict) else ''
    begin = rec.get('Begin', '')
    sport = rec.get('Sport', {}).get('#text', '') if isinstance(rec.get('Sport'), dict) else ''
    category = rec.get('Category', {}).get('#text', '') if isinstance(rec.get('Category'), dict) else ''
    tournament = rec.get('Tournament', {}).get('#text', '') if isinstance(rec.get('Tournament'), dict) else ''
    
    channels_data = rec.get('Channels', {}).get('Channel', [])
    if isinstance(channels_data, dict):
        channels_data = [channels_data]
    
    seen_channels = set()
    channels = []
    for ch in channels_data:
        if isinstance(ch, dict):
            name = ch.get('Name', '?')
            country = ch.get('Country', '?')
            # Chiave univoca per deduplicazione (case-insensitive)
            key = (name.lower().strip(), country.lower().strip())
            if key not in seen_channels:
                channels.append({
                    "name": name,
                    "country": country
                })
                seen_channels.add(key)
            
    # Estrai solo l'ora dal formato "Wednesday, 18 March 2026 15:30"
    time_str = begin
    time_m = re.search(r'(\d{1,2}:\d{2})$', begin)
    if time_m:
        time_str = time_m.group(1)
        
    # Costruisci il titolo e pulisci eventuali simboli non standard/emoji
    title = f"{team1} - {team2}" if team2 else team1
    if not title:
        title = tournament
    
    # Rimuovi solo le Emoji (caratteri fuori dal piano BMP) per compatibilità Kodi
    # mantenendo però i caratteri accentati standard (Latin-1/UTF-8 base)
    title = "".join(c for c in title if ord(c) < 65536).replace('  ', ' ').strip()
        
    return {
        "time": time_str,
        "title": title,
        "sport": sport,
        "category": category,
        "tournament": tournament,
        "sources": channels
    }

def _filter_football(records):
    filtered = []
    for rec in records:
        parsed = _parse_record(rec)
        cat_lower = parsed["category"].lower()
        tourn_lower = parsed["tournament"].lower()
        
        match = False
        for f in FOOTBALL_FILTERS:
            cat_ok = f["category"] is None or f["category"] in cat_lower
            tourn_ok = f["tournament"] is None or f["tournament"] in tourn_lower
            
            if cat_ok and tourn_ok:
                # Escludi le divisioni amatoriali o femminili tedesche classificate come "Germany Amateur"
                if f.get("category") == "germany" and "amateur" in cat_lower:
                    continue
                match = True
                break
                
        if match:
            filtered.append(parsed)
    return filtered

def _filter_volleyball(records):
    filtered = []
    for rec in records:
        parsed = _parse_record(rec)
        title_lower = parsed["title"].lower()
        tourn_lower = parsed["tournament"].lower()
        
        has_italian_team = any(t in title_lower for t in ITALIAN_VOLLEY_TEAMS)
        is_italian_league = any(x in tourn_lower for x in ["serie a1", "serie a2", "coppa italia", "supercoppa"])
        # Aggiunta: Tornei CEV (Champions League, CEV Cup, Challenge Cup)
        is_cev_tournament = any(x in tourn_lower for x in ["cev", "champions league"])
        
        if has_italian_team or is_italian_league or is_cev_tournament:
            filtered.append(parsed)
    return filtered

def _filter_motorsport(records):
    filtered = []
    for rec in records:
        parsed = _parse_record(rec)
        combined = (parsed["tournament"] + " " + parsed["category"] + " " + parsed["title"]).lower()
        if any(t in combined for t in ["formula 1", "f1", "motogp", "moto gp", "moto2", "moto3"]):
            filtered.append(parsed)
    return filtered

# ─── CALENDARI MOTORI 2026 ───────────────────────────────────────

MOTOGP_CALENDAR_2026 = [
    {"name": "GP Thailandia", "start": "2026-02-27", "end": "2026-03-01"},
    {"name": "GP Brasile", "start": "2026-03-19", "end": "2026-03-21"},
    {"name": "GP USA", "start": "2026-03-27", "end": "2026-03-29"},
    {"name": "GP Portogallo", "start": "2026-04-10", "end": "2026-04-12"},
    {"name": "GP Jerez", "start": "2026-04-24", "end": "2026-04-26"},
    {"name": "GP Francia", "start": "2026-05-08", "end": "2026-05-10"},
    {"name": "GP Mugello", "start": "2026-05-22", "end": "2026-05-24"},
    {"name": "GP Catalunya", "start": "2026-06-05", "end": "2026-06-07"},
    {"name": "GP Olanda", "start": "2026-06-26", "end": "2026-06-28"},
    {"name": "GP Germania", "start": "2026-07-10", "end": "2026-07-12"},
    {"name": "GP Inghilterra", "start": "2026-07-31", "end": "2026-08-02"},
    {"name": "GP Austria", "start": "2026-08-14", "end": "2026-08-16"},
    {"name": "GP Ungheria", "start": "2026-08-21", "end": "2026-08-23"},
    {"name": "GP Aragon", "start": "2026-09-04", "end": "2026-09-06"},
    {"name": "GP San Marino", "start": "2026-09-11", "end": "2026-09-13"},
    {"name": "GP Giappone", "start": "2026-09-25", "end": "2026-09-27"},
    {"name": "GP Indonesia", "start": "2026-10-02", "end": "2026-10-04"},
    {"name": "GP Australia", "start": "2026-10-16", "end": "2026-10-18"},
    {"name": "GP Malesia", "start": "2026-10-23", "end": "2026-10-25"},
    {"name": "GP Valencia", "start": "2026-11-13", "end": "2026-11-15"},
]

F1_CALENDAR_2026 = [
    {"name": "GP Australia", "start": "2026-03-05", "end": "2026-03-08"},
    {"name": "GP Cina", "start": "2026-03-12", "end": "2026-03-15"},
    {"name": "GP Giappone", "start": "2026-03-26", "end": "2026-03-29"},
    {"name": "GP Bahrain", "start": "2026-04-09", "end": "2026-04-12"},
    {"name": "GP Arabia Saudita", "start": "2026-04-16", "end": "2026-04-19"},
    {"name": "GP Miami", "start": "2026-04-30", "end": "2026-05-03"},
    {"name": "GP Imola", "start": "2026-05-14", "end": "2026-05-17"},
    {"name": "GP Monaco", "start": "2026-05-21", "end": "2026-05-24"},
    {"name": "GP Spagna", "start": "2026-05-28", "end": "2026-05-31"},
    {"name": "GP Canada", "start": "2026-06-11", "end": "2026-06-14"},
    {"name": "GP Austria", "start": "2026-06-25", "end": "2026-06-28"},
    {"name": "GP Inghilterra", "start": "2026-07-02", "end": "2026-07-05"},
    {"name": "GP Belgio", "start": "2026-07-23", "end": "2026-07-26"},
    {"name": "GP Ungheria", "start": "2026-07-30", "end": "2026-08-02"},
    {"name": "GP Olanda", "start": "2026-08-20", "end": "2026-08-23"},
    {"name": "GP Italia (Monza)", "start": "2026-09-03", "end": "2026-09-06"},
    {"name": "GP Azerbaijan", "start": "2026-09-17", "end": "2026-09-20"},
    {"name": "GP Singapore", "start": "2026-10-01", "end": "2026-10-04"},
    {"name": "GP USA (Austin)", "start": "2026-10-15", "end": "2026-10-18"},
    {"name": "GP Messico", "start": "2026-10-22", "end": "2026-10-25"},
    {"name": "GP Brasile", "start": "2026-11-05", "end": "2026-11-08"},
    {"name": "GP Las Vegas", "start": "2026-11-19", "end": "2026-11-22"},
    {"name": "GP Qatar", "start": "2026-11-26", "end": "2026-11-29"},
    {"name": "GP Abu Dhabi", "start": "2026-12-03", "end": "2026-12-06"},
]

def _apply_motorsport_fallback(events):
    """Aggiunge eventi MotoGP/F1 se mancanti durante i weekend di gara."""
    today = datetime.date.today().isoformat()
    
    # Controlla se MotoGP è presente
    has_mgp = any("motogp" in ev["title"].lower() or "motogp" in ev["tournament"].lower() for ev in events)
    if not has_mgp:
        for gp in MOTOGP_CALENDAR_2026:
            if gp["start"] <= today <= gp["end"]:
                events.append({
                    "time": "08:00", 
                    "title": f"[COLOR gold][B]{gp['name']} MOTOGP[/B][/COLOR] (Weekend LIVE)",
                    "sport": "Motorsport", "category": "International", "tournament": "MotoGP",
                    "sources": [
                        {"name": "Sky Sport MotoGP", "country": "Italia"},
                        {"name": "ServusTV", "country": "Austria/Ger"},
                        {"name": "Canal+", "country": "Francia"},
                        {"name": "TNT Sports / BT Sport", "country": "UK"}
                    ]
                })
                break

    # Controlla se F1 è presente
    has_f1 = any("formula 1" in ev["title"].lower() or "f1" in ev["tournament"].lower() for ev in events)
    if not has_f1:
        for gp in F1_CALENDAR_2026:
            if gp["start"] <= today <= gp["end"]:
                events.append({
                    "time": "08:00",
                    "title": f"[COLOR cyan][B]{gp['name']} FORMULA 1[/B][/COLOR] (Weekend LIVE)",
                    "sport": "Motorsport", "category": "International", "tournament": "Formula 1",
                    "sources": [
                        {"name": "Sky Sport F1", "country": "Italia"},
                        {"name": "Sky Sports F1", "country": "UK"},
                        {"name": "Canal+ Sport", "country": "Francia"},
                        {"name": "RTBF / Tipik", "country": "Belgio"}
                    ]
                })
                break

def get_sporteventz_schedule():
    """Recupera l'agenda sportiva filtrando solo calcio, tennis, F1/MotoGP e volley italiano."""
    session = _create_session()
    all_events = []
    
    # 1. Calcio (homepage)
    fb_data = _fetch_page_json(session, "https://www.sporteventz.com/en/")
    if fb_data and 'Records' in fb_data:
        all_events.extend(_filter_football(fb_data['Records']))
        
    # 2. Tennis
    ten_data = _fetch_page_json(session, "https://www.sporteventz.com/en/other-sport/tennis.html")
    if ten_data and 'Records' in ten_data:
        all_events.extend([_parse_record(r) for r in ten_data['Records']])
        
    # 3. Motorsport (F1, MotoGP)
    mot_data = _fetch_page_json(session, "https://www.sporteventz.com/en/other-sport/motorsport.html")
    if mot_data and 'Records' in mot_data:
        all_events.extend(_filter_motorsport(mot_data['Records']))
        
    # 4. Volley (Solo squadre/lega italiana)
    vol_data = _fetch_page_json(session, "https://www.sporteventz.com/en/other-sport/volleyball.html")
    if vol_data and 'Records' in vol_data:
        all_events.extend(_filter_volleyball(vol_data['Records']))
        
    # Deduplica eventi (stesso orario e stesso titolo)
    unique_events = {}
    for ev in all_events:
        key = (ev["time"], ev["title"].lower().strip())
        if key not in unique_events:
            unique_events[key] = ev
        else:
            # Opzionale: unisci i canali dei due eventi se duplicati con sorgenti diverse
            # Per ora ci fidiamo del primo trovato.
            pass
            
    final_events = list(unique_events.values())
    
    # --- SISTEMA DI EMERGENZA (Fallback Motori) ---
    _apply_motorsport_fallback(final_events)

    # Ordina cronologicamente (per orario HH:MM)
    final_events.sort(key=lambda x: x["time"])
    
    return final_events
