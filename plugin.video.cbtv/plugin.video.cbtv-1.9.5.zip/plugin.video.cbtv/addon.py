import sys
from urllib.parse import parse_qsl, urlencode
import xbmcgui
import xbmcplugin
import json
import re
import xbmc
import base64
import xml.etree.ElementTree as ET
from datetime import datetime, timedelta
import xbmcvfs
# from resources.lib.scraper import get_oasport_events # Rimosso in favore di EPG reale

import xbmcaddon
import os

# Global variables
ADDON = xbmcaddon.Addon()
ADDON_ID = 'plugin.video.cbtv'
HEADERS = {
    "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/121.0.0.0 Safari/537.36",
    "Accept": "application/json, text/plain, */*",
    "Origin": "https://www.sky.it",
    "Referer": "https://www.sky.it/"
}
HANDLE = int(sys.argv[1])
BASE_URL = sys.argv[0]

# Ensure absolute path for fanart
FANART = os.path.join(ADDON.getAddonInfo('path'), 'fanart.jpg')

# URL config remota su GitHub Pages
REMOTE_CONFIG_URL = "https://cb6-maker.github.io/repo.cbtv/channels_config.json"

# Cache config per evitare download multipli nella stessa sessione
_cached_config = None

def get_remote_config():
    """Scarica la config remota da GitHub. Se fallisce, usa i default hardcoded."""
    global _cached_config
    if _cached_config is not None:
        return _cached_config
    
    import requests
    try:
        xbmc.log(f"[CBTV] Scaricando config da {REMOTE_CONFIG_URL}", xbmc.LOGINFO)
        r = requests.get(REMOTE_CONFIG_URL, headers=HEADERS, timeout=5)
        if r.status_code == 200:
            _cached_config = r.json()
            xbmc.log(f"[CBTV] Config remota caricata (v{_cached_config.get('version', '?')})", xbmc.LOGINFO)
            return _cached_config
    except Exception as e:
        xbmc.log(f"[CBTV] Config remota non disponibile: {e}. Uso defaults.", xbmc.LOGWARNING)
    
    # Fallback hardcoded
    _cached_config = DEFAULT_CONFIG
    return _cached_config

# Default hardcoded (usato se GitHub non risponde)
DEFAULT_CONFIG = {
    "version": 0,
    "freeshot": {
        "player_base_url": "https://popcdn.day/player/",
        "stream_base_url": "https://planetary.lovecdn.ru/",
        "stream_path": "/tracks-v1a1/mono.m3u8",
        "referer": "https://thisnot.business/",
        "token_regex": 'currentToken: "([^"]+)"',
        "channels": [
            {"name": "Sky Sport 24", "code": "SkySport24IT", "sky_id": 9094},
            {"name": "Sky Sport Uno", "code": "SkySportUnoIT", "sky_id": 9097},
            {"name": "Sky Sport Calcio", "code": "SkySportCalcioIT", "sky_id": 9113},
            {"name": "Sky Sport Arena", "code": "SkySportArenaIT", "sky_id": 9093},
            {"name": "Sky Sport Max", "code": "SkySportMaxIT", "sky_id": 9103},
            {"name": "Sky Sport Tennis", "code": "SkySportTennisIT", "sky_id": 11237},
            {"name": "Sky Sport F1", "code": "SkySportF1IT", "sky_id": 9096},
            {"name": "Sky Sport MotoGP", "code": "SkySportMotoGPIT", "sky_id": 9102},
            {"name": "Sky Sport Basket", "code": "SkySportBasketIT", "sky_id": 9116},
            {"name": "Sky Sport Golf", "code": "SkySportGolfIT", "sky_id": 10254},
            {"name": "DAZN", "code": "ZonaDAZN", "sky_id": 11402}
        ]
    }
}

def build_url(query):
    return f"{BASE_URL}?{urlencode(query)}"

def add_directory_item(title, query, is_folder=True, icon=None, is_playable=False):
    url = build_url(query)
    list_item = xbmcgui.ListItem(label=title)
    
    # Set default fanart for everything
    art = {'fanart': FANART}
    if icon:
        art['icon'] = icon
        art['thumb'] = icon
    list_item.setArt(art)

    if is_playable:
        list_item.setProperty('IsPlayable', 'true')
    xbmcplugin.addDirectoryItem(handle=HANDLE, url=url, listitem=list_item, isFolder=is_folder)

def main_menu():
    xbmcplugin.setContent(HANDLE, 'videos')
    
    add_directory_item("[COLOR lime][B]Agenda Sportiva (Eventi di Oggi)[/B][/COLOR]", {"action": "list_agenda"})
    add_directory_item("[COLOR gold][B]Canali Sport[/B][/COLOR]", {"action": "list_sport"})
    add_directory_item("[COLOR yellow][B]Cinema e Intrattenimento[/B][/COLOR]", {"action": "list_premium_cinema"})
    
    xbmcplugin.endOfDirectory(HANDLE)

def list_sport():
    """Sottomenu Sport con tutte le sorgenti"""
    xbmcplugin.setContent(HANDLE, 'videos')
    
    add_directory_item("[COLOR lime][B]Sport Premium[/B][/COLOR]", {"action": "list_premium_sport"})
    add_directory_item("[COLOR gold][B]Sport SKY[/B][/COLOR]", {"action": "list_sport_sky"})
    add_directory_item("[COLOR cyan][B]Sport MPD Nazioni[/B][/COLOR]", {"action": "list_mpd_nazioni"})
    
    xbmcplugin.endOfDirectory(HANDLE)

def list_sport_sky():
    """Sottomenu Sky con le due sorgenti disponibili"""
    xbmcplugin.setContent(HANDLE, 'videos')
    
    add_directory_item("[COLOR gold][B]Sky Sport LIVE[/B][/COLOR] (Fonte 1)", {"action": "list_freeshot"})
    add_directory_item("[COLOR orange][B]Sky Sport 2[/B][/COLOR] (Fonte 2)", {"action": "list_mediahosting"})
    
    xbmcplugin.endOfDirectory(HANDLE)

# --- PREMIUM (MANDRAKODI SOURCE) ---

# Hardcoded config (no remote fetch to avoid load-time issues)
PREMIUM_URL = "https://test34344.herokuapp.com/filter.php"
PREMIUM_UA = "MandraKodi2@@1.1.2@@MandraKodi3@@S63TDC"
PROTECTION_KEY = "amstaff@@"

def list_premium_sport():
    """Show SPORT premium channels directly (no subfolder)"""
    import requests
    xbmcplugin.setContent(HANDLE, 'videos')
    url = f"{PREMIUM_URL}?numTest=A1A260"
    headers = {"User-Agent": PREMIUM_UA}
    
    try:
        r = requests.get(url, headers=headers, timeout=10)
        data = r.json()
        sections = data.get("channels", [])
        
        for sec in sections:
            name = sec.get("name", "Unknown Group")
            # Show channels directly from SPORT sections
            if "SPORT" in name.upper():
                for it in sec.get("items", []):
                    resolve_val = it.get("myresolve", "")
                    if PROTECTION_KEY in resolve_val:
                        payload = resolve_val.split("@@")[1]
                        title = it.get("title", "Canale")
                        add_directory_item(
                            title, 
                            {"action": "play_premium", "payload": payload, "title": title},
                            is_folder=False,
                            is_playable=True,
                            icon=it.get("thumbnail")
                        )
                
    except Exception as e:
        xbmcgui.Dialog().ok("Errore Premium", f"Impossibile caricare i canali Premium: {str(e)}")
        
    xbmcplugin.endOfDirectory(HANDLE)

def list_premium_cinema():
    """Show Cinema, Intrattenimento, and Bambini channels"""
    import requests
    xbmcplugin.setContent(HANDLE, 'videos')
    url = f"{PREMIUM_URL}?numTest=A1A260"
    headers = {"User-Agent": PREMIUM_UA}
    
    try:
        r = requests.get(url, headers=headers, timeout=10)
        data = r.json()
        sections = data.get("channels", [])
        
        for sec in sections:
            name = sec.get("name", "Unknown Group")
            # Show everything EXCEPT Sport (Cinema, Intrattenimento, Bambini)
            if "SPORT" not in name.upper():
                 add_directory_item(name, {"action": "list_premium_category", "cat_data": json.dumps(sec)})
                
    except Exception as e:
        xbmcgui.Dialog().ok("Errore Premium", f"Impossibile caricare i canali Premium: {str(e)}")
        
    xbmcplugin.endOfDirectory(HANDLE)

def list_premium_category(cat_data):
    sec = json.loads(cat_data)
    items = sec.get("items", [])
    
    for it in items:
        # Mandrakodi uses 'myresolve' with protection key
        resolve_val = it.get("myresolve", "")
        if PROTECTION_KEY in resolve_val:
            payload = resolve_val.split("@@")[1]
            title = it.get("title", "Canale")
            add_directory_item(
                title, 
                {"action": "play_premium", "payload": payload, "title": title},
                is_folder=False,
                is_playable=True,
                icon=it.get("thumbnail")
            )
            
    xbmcplugin.endOfDirectory(HANDLE)

def play_premium(payload, title):
    import base64
    
    # Fix padding for base64
    missing_padding = len(payload) % 4
    if missing_padding:
        payload += '=' * (4 - missing_padding)
        
    try:
        decoded = base64.b64decode(payload).decode('utf-8')
        parts = decoded.split('|')
        
        stream_url = parts[0]
        clearkey = parts[1] if len(parts) > 1 else None
        
        # NowTV/Sky uses these headers
        ua = "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/119.0.0.0 Safari/537.36"
        host = "https://www.nowtv.it"
        headers = f"User-Agent={ua}&Referer={host}/&Origin={host}&verifypeer=false"
        
        list_item = xbmcgui.ListItem(path=stream_url)
        list_item.setInfo('video', {'title': title})
        
        # Set InputStream Adaptive properties
        list_item.setProperty('inputstream', 'inputstream.adaptive')
        if ".mpd" in stream_url:
            list_item.setProperty('inputstream.adaptive.file_type', 'mpd')
            list_item.setMimeType("application/dash+xml")
        elif ".m3u8" in stream_url:
            list_item.setProperty('inputstream.adaptive.file_type', 'hls')
            list_item.setMimeType("application/x-mpegURL")
            
        if clearkey and clearkey != "0000":
            list_item.setProperty('inputstream.adaptive.drm_legacy', f'org.w3.clearkey|{clearkey}')
            
        list_item.setProperty('inputstream.adaptive.stream_headers', headers)
        list_item.setProperty('inputstream.adaptive.manifest_headers', headers)
        
        xbmcplugin.setResolvedUrl(HANDLE, True, listitem=list_item)
        
    except Exception as e:
        xbmcgui.Dialog().notification("Errore Play", f"Errore decodifica: {str(e)}", xbmcgui.NOTIFICATION_ERROR)

# --- FREESHOT (SKY SPORT LIVE) ---

def list_freeshot():
    """Lista canali Sky Sport via Freeshot (da config remota)"""
    xbmcplugin.setContent(HANDLE, 'videos')
    
    cfg = get_remote_config()
    channels = cfg.get("freeshot", {}).get("channels", [])
    
    for ch in channels:
        add_directory_item(
            ch["name"],
            {"action": "play_freeshot", "code": ch["code"], "title": ch["name"]},
            is_folder=False,
            is_playable=True
        )
        
    xbmcplugin.endOfDirectory(HANDLE)

def play_freeshot(code, title):
    """Risolvi e riproduci un canale Freeshot (endpoint da config remota)"""
    import requests
    
    try:
        cfg = get_remote_config().get("freeshot", {})
        player_base = cfg.get("player_base_url", "https://popcdn.day/player/")
        stream_base = cfg.get("stream_base_url", "https://planetary.lovecdn.ru/")
        stream_path = cfg.get("stream_path", "/tracks-v1a1/mono.m3u8")
        referer = cfg.get("referer", "https://thisnot.business/")
        token_regex = cfg.get("token_regex", 'currentToken: "([^"]+)"')
        
        xbmc.log(f"[CBTV] Freeshot: risolvendo {title} ({code})", xbmc.LOGINFO)
        
        ua = "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/135.0.0.0 Safari/537.36 OPR/120.0.0.0"
        
        # Step 1: Ottieni il token
        s = requests.Session()
        headers = {'User-Agent': ua, 'Referer': referer}
        page_url = f"{player_base}{code}"
        
        r = s.get(page_url, headers=headers, timeout=10)
        
        match = re.search(token_regex, r.text)
        if not match:
            raise Exception(f"Token non trovato per {code}")
            
        token = match.group(1)
        xbmc.log(f"[CBTV] Freeshot token ottenuto: {token[:30]}...", xbmc.LOGINFO)
        
        # Step 2: Costruisci URL stream
        stream_url = f"{stream_base}{code}{stream_path}?token={token}"
        xbmc.log(f"[CBTV] Freeshot stream: {stream_url}", xbmc.LOGINFO)
        
        # Step 3: Play con inputstream.ffmpegdirect
        list_item = xbmcgui.ListItem(path=stream_url)
        list_item.setInfo('video', {'title': title})
        list_item.setProperty('inputstream', 'inputstream.ffmpegdirect')
        list_item.setProperty('inputstream.ffmpegdirect.is_realtime_stream', 'true')
        list_item.setProperty('inputstream.ffmpegdirect.manifest_type', 'hls')
        list_item.setMimeType('application/x-mpegURL')
        list_item.setContentLookup(False)
        
        xbmcplugin.setResolvedUrl(HANDLE, True, listitem=list_item)
        
    except Exception as e:
        xbmc.log(f"[CBTV] Errore Freeshot: {str(e)}", xbmc.LOGERROR)
        xbmcgui.Dialog().notification("Errore Freeshot", str(e), xbmcgui.NOTIFICATION_ERROR)
        xbmcplugin.setResolvedUrl(HANDLE, False, xbmcgui.ListItem())

# --- MEDIAHOSTING (SKY SPORT 2 - Backup) ---

def list_mediahosting():
    """Lista canali Sky Sport via Mediahosting (da config remota)"""
    xbmcplugin.setContent(HANDLE, 'videos')
    
    cfg = get_remote_config()
    channels = cfg.get("mediahosting", {}).get("channels", [])
    
    for ch in channels:
        add_directory_item(
            ch["name"],
            {"action": "play_mediahosting", "code": ch["code"], "title": ch["name"]},
            is_folder=False,
            is_playable=True
        )
        
    xbmcplugin.endOfDirectory(HANDLE)

def play_mediahosting(code, title):
    """Risolvi e riproduci un canale Mediahosting (endpoint da config remota)"""
    import requests
    
    try:
        cfg = get_remote_config().get("mediahosting", {})
        embed_base = cfg.get("embed_base_url", "https://mediahosting.space/embed/player?stream=")
        referer = cfg.get("referer", "https://mediahosting.space/")
        source_regex = cfg.get("source_regex", '<source src="(.*?)"')
        
        xbmc.log(f"[CBTV] Mediahosting: risolvendo {title} (stream {code})", xbmc.LOGINFO)
        
        # Step 1: Ottieni URL stream dalla pagina embed
        player_url = f"{embed_base}{code}"
        headers = {'Referer': referer}
        
        r = requests.get(player_url, headers=headers, timeout=15)
        
        match = re.search(source_regex, r.text)
        if not match:
            raise Exception(f"Stream URL non trovato per stream {code}")
            
        stream_url = match.group(1)
        xbmc.log(f"[CBTV] Mediahosting stream: {stream_url}", xbmc.LOGINFO)
        
        # Step 2: Play diretto (URL HLS standard .m3u8)
        list_item = xbmcgui.ListItem(path=stream_url)
        list_item.setInfo('video', {'title': title})
        list_item.setProperty('inputstream', 'inputstream.ffmpegdirect')
        list_item.setProperty('inputstream.ffmpegdirect.is_realtime_stream', 'true')
        list_item.setProperty('inputstream.ffmpegdirect.manifest_type', 'hls')
        list_item.setMimeType('application/x-mpegURL')
        list_item.setContentLookup(False)
        
        xbmcplugin.setResolvedUrl(HANDLE, True, listitem=list_item)
        
    except Exception as e:
        xbmc.log(f"[CBTV] Errore Mediahosting: {str(e)}", xbmc.LOGERROR)
        xbmcgui.Dialog().notification("Errore Mediahosting", str(e), xbmcgui.NOTIFICATION_ERROR)
        xbmcplugin.setResolvedUrl(HANDLE, False, xbmcgui.ListItem())

# --- AGENDA (SCRAPER) ---

# --- AGENDA INTELLIGENTE (EPG DRIVEN) ---

def get_today_dates():
    from datetime import datetime
    now = datetime.now()
    today = now.strftime("%Y-%m-%d")
    return today

def get_cache_path(filename):
    """Ritorna il percorso della cache per l'addon"""
    path = xbmcvfs.translatePath(ADDON.getAddonInfo('profile'))
    if not os.path.exists(path):
        os.makedirs(path)
    return os.path.join(path, filename)

def download_xmltv_cached(url, name):
    """Scarica XMLTV e lo salva in cache per 24 ore"""
    import requests
    cache_file = get_cache_path(f"epg_{name}.xml")
    
    # Controlla se il file esiste ed è recente
    if os.path.exists(cache_file):
        mtime = os.path.getmtime(cache_file)
        if datetime.now().timestamp() - mtime < 86400: # 24 ore
            return cache_file
            
    try:
        xbmc.log(f"[CBTV] Scaricando XMLTV {name} da {url}", xbmc.LOGINFO)
        r = requests.get(url, headers=HEADERS, timeout=15)
        if r.status_code == 200:
            with open(cache_file, "wb") as f:
                f.write(r.content)
            return cache_file
        else:
            xbmc.log(f"[CBTV] Errore download XMLTV {name}: {r.status_code}", xbmc.LOGWARNING)
    except Exception as e:
        xbmc.log(f"[CBTV] Eccezione download XMLTV {name}: {e}", xbmc.LOGERROR)
    return cache_file if os.path.exists(cache_file) else None

def parse_xmltv(file_path, country_name):
    """Parsa file XMLTV e estrae eventi sportivi di oggi e domani"""
    events = []
    if not file_path or not os.path.exists(file_path): return events
    
    try:
        tree = ET.parse(file_path)
        root = tree.getroot()
        
        # Prendiamo eventi di ieri, oggi e domani per gestire fusi orari
        day_zero = (datetime.now() - timedelta(days=1)).strftime("%Y%m%d")
        day_one = datetime.now().strftime("%Y%m%d")
        day_two = (datetime.now() + timedelta(days=1)).strftime("%Y%m%d")
        allowed_days = [day_zero, day_one, day_two]
        
        # Mappa canali per ID
        channels_map = {}
        for chan in root.findall('channel'):
            id = chan.get('id')
            dn_node = chan.find('display-name')
            display_name = dn_node.text if dn_node is not None else id
            channels_map[id] = display_name

        for prog in root.findall('programme'):
            start = prog.get('start') # Formato: 20240210204500 +0000
            if not any(start.startswith(d) for d in allowed_days): continue
            
            title_node = prog.find('title')
            title = title_node.text if title_node is not None else "Evento"
            channel_id = prog.get('channel')
            channel_name = channels_map.get(channel_id, channel_id)
            
            # Parsing ora e data per calcolo differenza (formato compatto per il match)
            # Salviamo l'oggetto datetime per il matching flessibile
            try:
                dt_start = datetime.strptime(start[:14], "%Y%m%d%H%M%S")
            except: continue
            
            events.append({
                "title": title,
                "dt": dt_start,
                "time": f"{start[8:10]}:{start[10:12]}",
                "channel": channel_name,
                "country": country_name
            })
    except Exception as e:
        xbmc.log(f"[CBTV] Errore parsing XMLTV {country_name}: {e}", xbmc.LOGERROR)
        
    return events

def get_mpd_link_for_foreign(channel_name, country):
    """Cerca un link MPD Amstaff per un canale straniero"""
    # Questa è una mappatura euristica. In futuro potremmo scaricare la lista MPD e matchare.
    # Per ora usiamo i canali principali conosciuti.
    mapping = {
        "MOVISTAR LALIGA": "amstaff@@...", # Esempio
        "CANAL+ SPORT": "amstaff@@...",
    }
    # Per ora restituiamo una label che indica la nazione, la risoluzione avverrà via MPD Nazioni
    return {"name": channel_name, "country": country}

def list_agenda():
    """Agenda Universale: Aggrega Sky + Esteri e applica filtri sportivi puri"""
    import requests
    xbmcplugin.setContent(HANDLE, 'videos')
    
    cfg = get_remote_config()
    today = get_today_dates()
    p_dialog = xbmcgui.DialogProgress()
    p_dialog.create('CBTV', 'Generazione Agenda Universale...')

    # Whitelists Campioni (Sempre validi ovunque siano)
    W_TENNIS = ["SINNER", "MUSETTI", "PAOLINI", "ALCARAZ", "DJOKOVIC", "BERRETTINI", "NADAL", "MEDVEDEV", "ERRANI", "BRONZETTI", "COCCIARETTO"]
    
    # Parole chiave per canali sportivi (Se il canale è tra questi, prendiamo tutto tranne la blacklist)
    SPORT_CH_KEYWORDS = ["SPORT", "CALCIO", "DAZN", "LALIGA", "MOVISTAR", "CANAL+", "BEIN", "POLSAT", "F1", "MOTOGP", "EUROSPORT", "ELEVEN"]

    # Blacklist (Cose che NON vogliamo vedere mai)
    BLACKLIST = ["NEWS", "TG", "STUDIO", "PRESENTAZIONE", "ANTEPRIMA", "IL CALCIO E' SERVITO", "RASSEGNA", "DAILY", "PADDOCK LIVE", "RACE ANATOMY", "MAGAZINE", "HIGHLIGHTS"]

    raw_events = []

    # 1. Scarica Sky IT
    p_dialog.update(20, "Recupero dati Sky Italia...")
    sky_channels_data = cfg.get("freeshot", {}).get("channels", [])
    sky_ids = list(set([ch["sky_id"] for ch in sky_channels_data if "sky_id" in ch]))
    sky_it_api = cfg.get("sky_it_api_base", "https://apid.sky.it/gtv/v1/events")
    
    for i, sid in enumerate(sky_ids):
        if p_dialog.iscanceled(): break
        p_dialog.update(20 + int((i / len(sky_ids)) * 20), f"Sky IT: Scansione canale {i+1}/{len(sky_ids)}...")
        try:
            # Endpoint corretto con pageNum e pageSize gestibili
            url = f"{sky_it_api}?from={today}T00:00:00Z&to={today}T23:59:59Z&pageSize=100&pageNum=0&env=DTH&channels={sid}"
            r = requests.get(url, headers=HEADERS, timeout=5)
            if r.status_code == 200:
                data = r.json()
                ev_list = data.get("events", [])
                xbmc.log(f"[CBTV] Sky ID {sid}: Trovati {len(ev_list)} eventi", xbmc.LOGINFO)
                for ev in ev_list:
                    name = ev.get("eventTitle", "").upper()
                    ch_name = next((c["name"] for c in sky_channels_data if c.get("sky_id") == sid), "Sky Sport")
                    start_raw = ev.get("starttime", "")
                    time_str = start_raw.split("T")[1][:5] if "T" in start_raw else "00:00"
                    raw_events.append({"title": name, "time": time_str, "ch": ch_name, "type": "sky", "code": sid})
            else:
                xbmc.log(f"[CBTV] Sky ID {sid} fallito: {r.status_code}", xbmc.LOGWARNING)
        except Exception as e:
            xbmc.log(f"[CBTV] Errore Sky ID {sid}: {e}", xbmc.LOGERROR)

    # 2. Scarica XMLTV Esteri
    foreign_sources = cfg.get("foreign_epg_sources", [])
    for src in foreign_sources:
        p_dialog.update(50, f"Recupero dati {src['name']}...")
        xml_file = download_xmltv_cached(src["url"], src["name"])
        if xml_file:
            xml_data = parse_xmltv(xml_file, src["name"])
            for f_ev in xml_data:
                raw_events.append({
                    "title": f_ev["title"].upper(),
                    "time": f_ev["time"],
                    "ch": f_ev["channel"],
                    "type": "mpd",
                    "country": f_ev["country"]
                })

    # 3. FILTRAGGIO INTELLIGENTE
    grouped = {}
    p_dialog.update(80, "Analisi eventi in corso...")
    
    for ev in raw_events:
        title = ev["title"]
        ch = ev["ch"].upper()
        
        # A. Filtro Blacklist INFLESSIBILE
        if any(b in title for b in BLACKLIST): continue
        
        # B. Identifica se è un canale sportivo
        is_sport_ch = any(k in ch for k in SPORT_CH_KEYWORDS)
        
        # C. Logica di inclusione
        keep = False
        # 1. È un canale sportivo? Teniamo quasi tutto (tranne blacklist già fatta)
        if is_sport_ch: keep = True
        # 2. MATCH? (Team A vs Team B o Team A - Team B)
        elif any(sep in title for sep in [" - ", " V ", " VS ", " .V. "]): keep = True
        # 3. Whitelist Campioni
        elif any(w in title for w in W_TENNIS): keep = True
        # 4. Motori (Gara/Qualifiche)
        elif any(k in title for k in ["GARA", "GP ", "GP:", "QUALIFICHE", "FINAL"]): keep = True
        
        if not keep: continue

        # Grouping
        match_title = re.sub(r'[^A-Z0-9]', '', title).strip()
        found_group = False
        for key in grouped:
            if match_title in key or key in match_title:
                # Se l'ora è simile (entro 30 min)
                found_group = True
                grouped[key]["sources"].append(ev)
                break
        if not found_group:
            grouped[match_title] = {
                "display_title": title,
                "time": ev["time"],
                "sources": [ev]
            }

    p_dialog.close()
    
    if not grouped:
        xbmc.log("[CBTV] Agenda vuota dopo il filtraggio!", xbmc.LOGWARNING)
        xbmcgui.Dialog().notification("Agenda", "Nessun evento sportivo trovato per oggi", xbmcgui.NOTIFICATION_INFO)
        xbmcplugin.endOfDirectory(HANDLE)
        return

    # 4. Mostra in lista
    xbmc.log(f"[CBTV] Agenda: {len(raw_events)} eventi grezzi trovati, {len(grouped)} gruppi dopo i filtri", xbmc.LOGINFO)
    sorted_events = sorted(grouped.values(), key=lambda x: x['time'])
    for ge in sorted_events:
        count = len(ge["sources"])
        # Colore per evidenziare eventi con molte fonti (es. Sinner o Calcio Big)
        color = "gold" if count > 2 else "white"
        label = f"[COLOR {color}]{ge['time']}[/COLOR] - [COLOR white]{ge['display_title']}[/COLOR] ([COLOR cyan]{count} fonti[/COLOR])"
        
        add_directory_item(
            label,
            {"action": "resolve_event_sources_v2", "event_json": json.dumps(ge)},
            is_folder=True
        )
        
    xbmcplugin.endOfDirectory(HANDLE)

def resolve_event_sources_v2(event_json):
    """Genera sottomenu con tutte le fonti (Sky IT, Premium, MPD)"""
    ge = json.loads(event_json)
    xbmcplugin.setContent(HANDLE, 'videos')
    
    cfg = get_remote_config()
    # Recupera lista canali Premium per il matching finale
    premium_list = []
    try:
        r_prem = requests.get(f"{PREMIUM_URL}?numTest=A1A260", headers=HEADERS, timeout=5).json()
        for sec in r_prem.get("channels", []):
            if "SPORT" in sec.get("name", "").upper():
                premium_list.extend(sec.get("items", []))
    except: pass

    for src in ge["sources"]:
        # 1. Se è una fonte SKY It, aggiungi Freeshot, Mediahosting e Premium
        if src["type"] == "sky":
            sid = src["code"]
            # Freeshot
            ch_f = next((c for c in cfg.get("freeshot", {}).get("channels", []) if c.get("sky_id") == sid), None)
            if ch_f:
                add_directory_item(f"[COLOR gold][FREESHOT][/COLOR] {ch_f['name']}", 
                                   {"action": "play_freeshot", "code": ch_f["code"], "title": ge["display_title"]}, 
                                   is_folder=False, is_playable=True)
            # Mediahosting
            ch_m = next((c for c in cfg.get("mediahosting", {}).get("channels", []) if c.get("sky_id") == sid), None)
            if ch_m:
                add_directory_item(f"[COLOR orange][MEDIAHOST][/COLOR] {ch_m['name']}", 
                                   {"action": "play_mediahosting", "code": ch_m["code"], "title": ge["display_title"]}, 
                                   is_folder=False, is_playable=True)
            # Premium Matching
            match_key = src["ch"].replace("Sky ", "").upper().strip()
            for p in premium_list:
                if match_key in p["title"].upper():
                    payload = p["myresolve"].split("@@")[1]
                    add_directory_item(f"[COLOR lime][PREMIUM][/COLOR] {p['title']}", 
                                       {"action": "play_premium", "payload": payload, "title": ge["display_title"]}, 
                                       is_folder=False, is_playable=True)
        
        # 2. Se è una fonte Estera (MPD)
        elif src["type"] == "mpd":
            label = f"[COLOR cyan][{src['country'].upper()}][/COLOR] {src['ch']} (Cerca in MPD)"
            add_directory_item(label, {"action": "list_mpd_nazioni", "search": src["ch"]}, is_folder=True)

    xbmcplugin.endOfDirectory(HANDLE)


# --- MPD NAZIONI (MANDRAKODI SPORT SOURCE) ---

MPD_NAZIONI_URL = "https://test34344.herokuapp.com/filter.php?numTest=A1A134A"
MPD_UA = "MandraKodi2@@1.2.78@@MandraKodi3@@S63TDC"

def list_mpd_nazioni():
    """Show list of countries from MPD Nazioni"""
    import requests
    xbmcplugin.setContent(HANDLE, 'videos')
    
    try:
        headers = {"User-Agent": MPD_UA}
        r = requests.get(MPD_NAZIONI_URL, headers=headers, timeout=10)
        data = r.json()
        countries = data.get("channels", [])
        
        for country in countries:
            name = country.get("name", "Unknown")
            # Clean color tags for display
            clean_name = re.sub(r'\[.*?\]', '', name).strip()
            thumb = country.get("thumbnail")
            
            add_directory_item(
                clean_name,
                {"action": "list_mpd_channels", "country_data": json.dumps(country)},
                icon=thumb
            )
    except Exception as e:
        xbmcgui.Dialog().notification("MPD Nazioni", f"Errore: {str(e)}", xbmcgui.NOTIFICATION_ERROR)
    
    xbmcplugin.endOfDirectory(HANDLE)

def list_mpd_channels(country_data):
    """Show channels for selected country"""
    import requests
    xbmcplugin.setContent(HANDLE, 'videos')
    
    try:
        country = json.loads(country_data)
        items = country.get("items", [])
        
        for ch in items:
            title = ch.get("title", "No Title")
            # Clean color tags
            clean_title = re.sub(r'\[.*?\]', '', title).strip()
            thumb = ch.get("thumbnail")
            myresolve = ch.get("myresolve", "")
            
            # Check if this is an MPD channel (has amstaff@@ prefix)
            if myresolve and "@@" in myresolve:
                # Make it a FOLDER that opens a submenu (like Mandrakodi)
                add_directory_item(
                    f"[COLOR cyan]{clean_title}[/COLOR]",
                    {"action": "show_mpd_play", "resolve_data": myresolve, "channel_name": clean_title},
                    is_folder=True,  # Changed to True - opens submenu
                    is_playable=False,
                    icon=thumb
                )
    except Exception as e:
        xbmcgui.Dialog().notification("MPD Canali", f"Errore: {str(e)}", xbmcgui.NOTIFICATION_ERROR)
    
    xbmcplugin.endOfDirectory(HANDLE)

def show_mpd_play(resolve_data, channel_name):
    """Show 'PLAY STREAM' option for the selected channel (Mandrakodi-style)"""
    xbmcplugin.setContent(HANDLE, 'videos')
    
    try:
        # Extract payload after @@
        payload = resolve_data.split("@@")[1]
        
        # Check if payload is a direct URL or Base64-encoded
        if payload.startswith("http://") or payload.startswith("https://"):
            # Direct URL format (e.g., RAI Sport)
            # Format: https://example.com/stream.mpd|0000 or |KID:KEY
            parts = payload.split("|")
            stream_url = parts[0]
            license_data = parts[1] if len(parts) > 1 else ""
        else:
            # Base64-encoded format (most channels)
            # Add padding if needed
            missing_padding = len(payload) % 4
            if missing_padding:
                payload += '=' * (4 - missing_padding)
            
            # Decode Base64
            decoded = base64.b64decode(payload).decode('utf-8')
            parts = decoded.split("|")
            stream_url = parts[0]
            license_data = parts[1] if len(parts) > 1 else ""
        
        # Create ListItem with path already set (like Mandrakodi)
        list_item = xbmcgui.ListItem(label="[COLOR lime]PLAY STREAM[/COLOR]", path=stream_url, offscreen=True)
        list_item.setInfo('video', {'title': channel_name})
        list_item.setProperty('IsPlayable', 'true')
        list_item.setContentLookup(False)
        
        # Set inputstream.adaptive
        list_item.setProperty('inputstream', 'inputstream.adaptive')
        
        # Set MIME type for MPD
        if ".mpd" in stream_url:
            list_item.setMimeType("application/dash+xml")
        
        # Set Clearkey DRM using drm_legacy (like Mandrakodi does!)
        # Note: license_data="0000" means no DRM (unencrypted stream)
        if license_data and ":" in license_data and license_data != "0000":
            drm_type = "org.w3.clearkey"
            # Format: org.w3.clearkey|KID:KEY
            list_item.setProperty('inputstream.adaptive.drm_legacy', f"{drm_type}|{license_data}")
        
        # Add as directory item
        xbmcplugin.addDirectoryItem(
            handle=HANDLE,
            url=stream_url,
            listitem=list_item,
            isFolder=False
        )
        
    except Exception as e:
        xbmcgui.Dialog().notification("MPD Play", f"Errore: {str(e)}", xbmcgui.NOTIFICATION_ERROR)
    
    xbmcplugin.endOfDirectory(HANDLE)

def play_mpd(resolve_data):
    """Decode and play MPD stream with Clearkey DRM"""
    try:
        # Extract payload after @@
        payload = resolve_data.split("@@")[1]
        
        # Check if payload is a direct URL or Base64-encoded
        if payload.startswith("http://") or payload.startswith("https://"):
            # Direct URL format (e.g., RAI Sport)
            parts = payload.split("|")
            stream_url = parts[0]
            license_data = parts[1] if len(parts) > 1 else ""
        else:
            # Base64-encoded format (most channels)
            # Add padding if needed
            missing_padding = len(payload) % 4
            if missing_padding:
                payload += '=' * (4 - missing_padding)
            
            # Decode Base64
            decoded = base64.b64decode(payload).decode('utf-8')
            
            # Parse URL|KID:KEY format
            parts = decoded.split("|")
            stream_url = parts[0]
            license_data = parts[1] if len(parts) > 1 else ""
        
        # Create ListItem for playback
        list_item = xbmcgui.ListItem(path=stream_url)
        
        # Set inputstream.adaptive for MPD playback
        list_item.setProperty('inputstream', 'inputstream.adaptive')
        list_item.setProperty('inputstream.adaptive.manifest_type', 'mpd')
        
        # Set Clearkey DRM if license key is provided
        # Note: license_data="0000" means no DRM (unencrypted stream)
        if license_data and ":" in license_data and license_data != "0000":
            # Split KID:KEY
            kid_key = license_data.split(":")
            kid = kid_key[0]
            key = kid_key[1]
            
            # Clearkey format for inputstream.adaptive
            # Some versions want JSON, others accept KID:KEY directly
            # Try the simple format first
            list_item.setProperty('inputstream.adaptive.license_type', 'clearkey')
            list_item.setProperty('inputstream.adaptive.license_key', license_data)
            
            # Alternative: Try JSON format (commented out for now)
            # clearkey_json = json.dumps({
            #     "keys": [{
            #         "kty": "oct",
            #         "kid": kid,
            #         "k": key
            #     }]
            # })
            # list_item.setProperty('inputstream.adaptive.license_key', clearkey_json)
        
        xbmcplugin.setResolvedUrl(HANDLE, True, list_item)
        
    except Exception as e:
        xbmcgui.Dialog().notification("Play MPD", f"Errore: {str(e)}", xbmcgui.NOTIFICATION_ERROR)
        xbmcplugin.setResolvedUrl(HANDLE, False, xbmcgui.ListItem())

if __name__ == '__main__':
    params = dict(parse_qsl(sys.argv[2][1:]))
    action = params.get('action')
    
    if not action: main_menu()
    elif action == 'list_agenda': list_agenda()
    elif action == 'resolve_event_sources_v2': resolve_event_sources_v2(params.get('event_json'))
    elif action == 'list_sport': list_sport()
    elif action == 'list_sport_sky': list_sport_sky()
    elif action == 'list_premium_sport': list_premium_sport()
    elif action == 'list_premium_cinema': list_premium_cinema()
    elif action == 'list_premium_category': list_premium_category(params.get('cat_data'))
    elif action == 'play_premium': play_premium(params.get('payload'), params.get('title'))
    elif action == 'list_mpd_nazioni': list_mpd_nazioni()
    elif action == 'list_mpd_channels': list_mpd_channels(params.get('country_data'))
    elif action == 'show_mpd_play': show_mpd_play(params.get('resolve_data'), params.get('channel_name'))
    elif action == 'play_mpd': play_mpd(params.get('resolve_data'))
    elif action == 'list_freeshot': list_freeshot()
    elif action == 'play_freeshot': play_freeshot(params.get('code'), params.get('title'))
    elif action == 'list_mediahosting': list_mediahosting()
    elif action == 'play_mediahosting': play_mediahosting(params.get('code'), params.get('title'))
    elif action == 'resolve_match_menu': resolve_match_menu(params.get('match_data'))
    elif action == 'resolve_menu': resolve_menu(params.get('url'), params.get('title'))
    elif action == 'play_internal': play_internal(params.get('url'), params.get('title'))

