import requests
import re
import datetime

# ─── CONFIG FILTRI ────────────────────────────────────────────────

# Tornei di calcio desiderati (match esatto su Categoria e Torneo)
FOOTBALL_FILTERS = [
    # Italia
    {"category": "italy", "tournament": "serie a"},
    {"category": "italy", "tournament": "serie b"},
    {"category": "italy", "tournament": "coppa italia"},
    
    # Coppe europee
    {"category": "international clubs", "tournament": "champions league"},
    {"category": "international clubs", "tournament": "europa league"},
    {"category": "international clubs", "tournament": "conference league"},
    {"category": "international clubs", "tournament": "super cup"},
    
    # Top campionati europei
    {"category": "england", "tournament": "premier league"},
    {"category": "spain", "tournament": "la liga"},
    {"category": "germany", "tournament": "bundesliga"},
    {"category": "france", "tournament": "ligue 1"},
    
    # Nazionali
    {"category": None, "tournament": "euro 202"},
    {"category": None, "tournament": "world cup"},
    {"category": None, "tournament": "nations league"},
]

# Squadre di volley italiane (femminili e maschili principali + nazionale)
ITALIAN_VOLLEY_TEAMS = [
    "perugia", "civitanova", "trento", "trentino", "modena", "monza", "milano",
    "piacenza", "verona", "padova", "taranto", "cisterna", "ravenna", "latina",
    "cuneo", "castellana", "lube", "vibo valentia",
    "conegliano", "novara", "scandicci", "busto arsizio", "firenze",
    "bergamo", "chieri", "roma", "vallefoglia", "casalmaggiore",
    "italy", "italia"
]

# ─── FUNZIONI CORE ────────────────────────────────────────────────

def _create_session():
    session = requests.Session()
    session.headers.update({
        "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36"
    })
    return session

def _fetch_page_json(session, page_url):
    try:
        resp = session.get(page_url, timeout=15)
        if resp.status_code != 200:
            return None
        m = re.search(r"listAction:\s*'(.*?)'", resp.text)
        if not m:
            return None
        
        # client_tz_offset=%2B0100 -> fuso orario Europa/Roma (+01:00)
        list_url = "https://www.sporteventz.com" + m.group(1) + "&client_tz_offset=%2B0100"
        
        resp_json = session.get(list_url, headers={
            "Accept": "application/json, text/javascript, */*; q=0.01",
            "X-Requested-With": "XMLHttpRequest",
            "Referer": page_url
        }, timeout=15)
        
        if not resp_json.text.strip():
            return {"Records": []}
            
        return resp_json.json()
    except Exception:
        return None

def _parse_record(rec):
    team1 = rec.get('Team1', {}).get('#text', '') if isinstance(rec.get('Team1'), dict) else ''
    team2 = rec.get('Team2', {}).get('#text', '') if isinstance(rec.get('Team2'), dict) else ''
    begin = rec.get('Begin', '')
    sport = rec.get('Sport', {}).get('#text', '') if isinstance(rec.get('Sport'), dict) else ''
    category = rec.get('Category', {}).get('#text', '') if isinstance(rec.get('Category'), dict) else ''
    tournament = rec.get('Tournament', {}).get('#text', '') if isinstance(rec.get('Tournament'), dict) else ''
    
    channels_data = rec.get('Channels', {}).get('Channel', [])
    if isinstance(channels_data, dict):
        channels_data = [channels_data]
    
    channels = []
    for ch in channels_data:
        if isinstance(ch, dict):
            channels.append({
                "name": ch.get('Name', '?'),
                "country": ch.get('Country', '?')
            })
            
    # Estrai solo l'ora dal formato "Wednesday, 18 March 2026 15:30"
    time_str = begin
    time_m = re.search(r'(\d{1,2}:\d{2})$', begin)
    if time_m:
        time_str = time_m.group(1)
        
    # Costruisci il titolo
    title = f"{team1} - {team2}" if team2 else team1
    if not title:
        title = tournament
        
    return {
        "time": time_str,
        "title": title,
        "sport": sport,
        "category": category,
        "tournament": tournament,
        "sources": channels
    }

def _filter_football(records):
    filtered = []
    for rec in records:
        parsed = _parse_record(rec)
        cat_lower = parsed["category"].lower()
        tourn_lower = parsed["tournament"].lower()
        
        match = False
        for f in FOOTBALL_FILTERS:
            cat_ok = f["category"] is None or f["category"] in cat_lower
            tourn_ok = f["tournament"] is None or f["tournament"] in tourn_lower
            
            if cat_ok and tourn_ok:
                # Escludi le divisioni amatoriali o femminili tedesche classificate come "Germany Amateur"
                if f.get("category") == "germany" and "amateur" in cat_lower:
                    continue
                match = True
                break
                
        if match:
            filtered.append(parsed)
    return filtered

def _filter_volleyball(records):
    filtered = []
    for rec in records:
        parsed = _parse_record(rec)
        title_lower = parsed["title"].lower()
        tourn_lower = parsed["tournament"].lower()
        
        has_italian_team = any(t in title_lower for t in ITALIAN_VOLLEY_TEAMS)
        is_italian_league = any(x in tourn_lower for x in ["serie a1", "serie a2", "coppa italia", "supercoppa"])
        
        if has_italian_team or is_italian_league:
            filtered.append(parsed)
    return filtered

def _filter_motorsport(records):
    filtered = []
    for rec in records:
        parsed = _parse_record(rec)
        combined = (parsed["tournament"] + " " + parsed["category"] + " " + parsed["title"]).lower()
        if any(t in combined for t in ["formula 1", "f1", "motogp", "moto gp", "moto2", "moto3"]):
            filtered.append(parsed)
    return filtered

def get_sporteventz_schedule():
    """Recupera l'agenda sportiva filtrando solo calcio, tennis, F1/MotoGP e volley italiano."""
    session = _create_session()
    all_events = []
    
    # 1. Calcio (homepage)
    fb_data = _fetch_page_json(session, "https://www.sporteventz.com/en/")
    if fb_data and 'Records' in fb_data:
        all_events.extend(_filter_football(fb_data['Records']))
        
    # 2. Tennis
    ten_data = _fetch_page_json(session, "https://www.sporteventz.com/en/other-sport/tennis.html")
    if ten_data and 'Records' in ten_data:
        all_events.extend([_parse_record(r) for r in ten_data['Records']])
        
    # 3. Motorsport (F1, MotoGP)
    mot_data = _fetch_page_json(session, "https://www.sporteventz.com/en/other-sport/motorsport.html")
    if mot_data and 'Records' in mot_data:
        all_events.extend(_filter_motorsport(mot_data['Records']))
        
    # 4. Volley (Solo squadre/lega italiana)
    vol_data = _fetch_page_json(session, "https://www.sporteventz.com/en/other-sport/volleyball.html")
    if vol_data and 'Records' in vol_data:
        all_events.extend(_filter_volleyball(vol_data['Records']))
        
    # Ordina cronologicamente (per orario HH:MM)
    all_events.sort(key=lambda x: x["time"])
    
    return all_events
