import requests
import re
from datetime import datetime, timedelta
import concurrent.futures

# Squadre di volley italiane (femminili e maschili principali + nazionale)
ITALIAN_VOLLEY_TEAMS = [
    "perugia", "civitanova", "trento", "trentino", "modena", "monza", "milano",
    "piacenza", "verona", "padova", "taranto", "cisterna", "ravenna", "latina",
    "cuneo", "castellana", "lube", "vibo valentia",
    "conegliano", "novara", "scandicci", "busto arsizio", "firenze",
    "bergamo", "chieri", "roma", "vallefoglia", "casalmaggiore",
    "italy", "italia"
]

def scrape_daddylive_page(cat_name, url):
    """Estrae gli eventi da una specifica pagina di DaddyLive (es. cat=Tennis)."""
    headers = {
        "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/122.0.0.0 Safari/537.36"
    }
    
    try:
        # Assicurati che l'URL sia completo
        if url.startswith('/'):
            url = f"https://dlstreams.top{url}"
            
        resp = requests.get(url, headers=headers, timeout=10)
        if resp.status_code != 200:
            return []
        
        html = resp.text
        all_events = []
        
        # Estrazione eventi
        events_blocks = html.split('<div class="schedule__event">')
        
        for ev_block in events_blocks[1:]:
            time_m = re.search(r'data-time="(\d{2}:\d{2})"', ev_block)
            title_m = re.search(r'<span class="schedule__eventTitle">(.*?)</span>', ev_block)
            
            if not time_m or not title_m:
                continue
            
            time_str = time_m.group(1)
            title = title_m.group(1).strip()
            
            # --- FILTRAGGIO AGGIUNTIVO ---
            t_low = title.lower()
            c_low = cat_name.lower()
            
            # Tennis: solo ATP/WTA, no Challenger
            if "tennis" in c_low or "tennis" in t_low:
                is_major = any(x in t_low or x in c_low for x in ["atp", "wta", "grand slam", "wimbledon", "roland garros", "australian open", "us open"])
                is_challenger = "challenger" in t_low or "challenger" in c_low
                if is_challenger or not is_major:
                    continue
            
            # Volley: solo Italiano o CEV
            if "volley" in c_low or "volley" in t_low:
                has_italian = any(team in t_low for team in ITALIAN_VOLLEY_TEAMS)
                is_cev = any(x in t_low for x in ["cev", "champions league"])
                if not (has_italian or is_cev):
                    continue
            
            # Channels
            channels = []
            ch_block_m = re.search(r'<div class="schedule__channels">(.*?)</div>', ev_block, re.DOTALL)
            if ch_block_m:
                ch_links = re.findall(r'<a[^>]*title="([^"]+)"[^>]*>', ch_block_m.group(1))
                for ch_title in ch_links:
                    channels.append({
                        "name": ch_title.strip(),
                        "country": "DaddyLive"
                    })
            
            seen_ch = set()
            unique_ch = []
            for c in channels:
                if c["name"] not in seen_ch:
                    unique_ch.append(c)
                    seen_ch.add(c["name"])
            channels = unique_ch
            
            # Orario UK -> Local (+1)
            try:
                t = datetime.strptime(time_str, "%H:%M")
                t = t + timedelta(hours=1)
                time_str = t.strftime("%H:%M")
            except:
                pass
            
            all_events.append({
                "time": time_str,
                "title": title,
                "sport": cat_name,
                "category": cat_name,
                "tournament": "",
                "sources": channels,
                "is_top": False
            })
            
        return all_events
    except Exception as e:
        # print(f"Errore scraping {cat_name}: {e}")
        return []

def get_daddylive_schedule():
    """Recupera l'agenda da DaddyLive scoprendo e scaricando solo le categorie ricedute."""
    base_url = "https://dlstreams.top/"
    headers = {
        "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/122.0.0.0 Safari/537.36"
    }
    
    try:
        # 1. Recupera la home per trovare i link delle categorie
        resp = requests.get(base_url, headers=headers, timeout=10)
        if resp.status_code != 200:
            return []
        
        # Parole chiave richieste dall'utente (sync con webapp)
        KEYWORDS = ["tennis", "motorsport", "volley", "f1", "motogp"]
        
        # Trova tutti i link alle categorie: <a class="" href="/index.php?cat=...">Nome Categoria</a>
        cat_links = re.findall(r'<a[^>]*href="(/index\.php\?cat=[^"]+)"[^>]*>(.*?)</a>', resp.text)
        
        to_scrape = []
        seen_urls = set()
        
        for url, name in cat_links:
            name_low = name.lower()
            if any(kw in name_low for kw in KEYWORDS):
                full_url = f"https://dlstreams.top{url}"
                if full_url not in seen_urls:
                    to_scrape.append((name, full_url))
                    seen_urls.add(full_url)
        
        all_events = []
        
        # 2. Scarica in parallelo le categorie identificate
        with concurrent.futures.ThreadPoolExecutor(max_workers=len(to_scrape) or 1) as executor:
            futures = {executor.submit(scrape_daddylive_page, name, url): name for name, url in to_scrape}
            
            for future in concurrent.futures.as_completed(futures):
                results = future.result()
                if results:
                    all_events.extend(results)
                    
        return all_events
        
    except Exception:
        return []
