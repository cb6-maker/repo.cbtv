import sys
from urllib.parse import parse_qsl, urlencode
import xbmcgui
import xbmcplugin
import json
import re
import xbmc
import base64
import xml.etree.ElementTree as ET
from datetime import datetime, timedelta
import xbmcvfs
# from resources.lib.scraper import get_oasport_events # Rimosso in favore di EPG reale

import xbmcaddon
import os

# Global variables
ADDON = xbmcaddon.Addon()
ADDON_ID = 'plugin.video.cbtv'
HEADERS = {
    "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/121.0.0.0 Safari/537.36",
    "Accept": "application/json, text/plain, */*",
    "Origin": "https://www.sky.it",
    "Referer": "https://www.sky.it/"
}
HANDLE = int(sys.argv[1])
BASE_URL = sys.argv[0]

# Ensure absolute path for fanart
FANART = os.path.join(ADDON.getAddonInfo('path'), 'fanart.jpg')

# URL config remota su GitHub Pages
REMOTE_CONFIG_URL = "https://cb6-maker.github.io/repo.cbtv/channels_config.json"

# Cache config per evitare download multipli nella stessa sessione
_cached_config = None

def get_remote_config():
    """Scarica la config remota da GitHub. Se fallisce, usa i default hardcoded."""
    global _cached_config
    if _cached_config is not None:
        return _cached_config
    
    import requests
    try:
        xbmc.log(f"[CBTV] Scaricando config da {REMOTE_CONFIG_URL}", xbmc.LOGINFO)
        r = requests.get(REMOTE_CONFIG_URL, headers=HEADERS, timeout=5)
        if r.status_code == 200:
            _cached_config = r.json()
            xbmc.log(f"[CBTV] Config remota caricata (v{_cached_config.get('version', '?')})", xbmc.LOGINFO)
            return _cached_config
    except Exception as e:
        xbmc.log(f"[CBTV] Config remota non disponibile: {e}. Uso defaults.", xbmc.LOGWARNING)
    
    # Fallback hardcoded
    _cached_config = DEFAULT_CONFIG
    return _cached_config

# Default hardcoded (usato se GitHub non risponde)
DEFAULT_CONFIG = {
    "version": 0,
    "freeshot": {
        "player_base_url": "https://popcdn.day/player/",
        "stream_base_url": "https://planetary.lovecdn.ru/",
        "stream_path": "/tracks-v1a1/mono.m3u8",
        "referer": "https://thisnot.business/",
        "token_regex": 'currentToken: "([^"]+)"',
        "channels": [
            {"name": "Sky Sport 24", "code": "SkySport24IT", "sky_id": 9094},
            {"name": "Sky Sport Uno", "code": "SkySportUnoIT", "sky_id": 9097},
            {"name": "Sky Sport Calcio", "code": "SkySportCalcioIT", "sky_id": 9113},
            {"name": "Sky Sport Arena", "code": "SkySportArenaIT", "sky_id": 9093},
            {"name": "Sky Sport Max", "code": "SkySportMaxIT", "sky_id": 9103},
            {"name": "Sky Sport Tennis", "code": "SkySportTennisIT", "sky_id": 11237},
            {"name": "Sky Sport F1", "code": "SkySportF1IT", "sky_id": 9096},
            {"name": "Sky Sport MotoGP", "code": "SkySportMotoGPIT", "sky_id": 9102},
            {"name": "Sky Sport Basket", "code": "SkySportBasketIT", "sky_id": 9116},
            {"name": "Sky Sport Golf", "code": "SkySportGolfIT", "sky_id": 10254},
            {"name": "DAZN", "code": "ZonaDAZN", "sky_id": 11402}
        ]
    }
}

def build_url(query):
    return f"{BASE_URL}?{urlencode(query)}"

def add_directory_item(title, query, is_folder=True, icon=None, is_playable=False):
    url = build_url(query)
    list_item = xbmcgui.ListItem(label=title)
    
    # Set default fanart for everything
    art = {'fanart': FANART}
    if icon:
        art['icon'] = icon
        art['thumb'] = icon
    list_item.setArt(art)

    if is_playable:
        list_item.setProperty('IsPlayable', 'true')
    xbmcplugin.addDirectoryItem(handle=HANDLE, url=url, listitem=list_item, isFolder=is_folder)

def main_menu():
    xbmcplugin.setContent(HANDLE, 'videos')
    
    add_directory_item("[COLOR lime][B]Agenda Sportiva (Eventi di Oggi)[/B][/COLOR]", {"action": "list_agenda"})
    add_directory_item("[COLOR gold][B]Canali Sport[/B][/COLOR]", {"action": "list_sport"})
    add_directory_item("Guida TV (Cinema & Intrattenimento)", {"action": "list_epg_entertainment"})
    add_directory_item("[COLOR yellow][B]Cinema e Intrattenimento[/B][/COLOR]", {"action": "list_premium_cinema"})
    
    xbmcplugin.endOfDirectory(HANDLE)

def list_sport():
    """Sottomenu Sport con tutte le sorgenti"""
    xbmcplugin.setContent(HANDLE, 'videos')
    
    add_directory_item("[COLOR lime][B]Sport Premium[/B][/COLOR]", {"action": "list_premium_sport"})
    add_directory_item("[COLOR gold][B]Sport SKY[/B][/COLOR]", {"action": "list_sport_sky"})
    add_directory_item("[COLOR cyan][B]Sport MPD Nazioni[/B][/COLOR]", {"action": "list_mpd_nazioni"})
    
    xbmcplugin.endOfDirectory(HANDLE)

def list_sport_sky():
    """Sottomenu Sky con le due sorgenti disponibili"""
    xbmcplugin.setContent(HANDLE, 'videos')
    
    add_directory_item("[COLOR gold][B]Sky Sport LIVE[/B][/COLOR] (Fonte 1)", {"action": "list_freeshot"})
    add_directory_item("[COLOR orange][B]Sky Sport 2[/B][/COLOR] (Fonte 2)", {"action": "list_mediahosting"})
    
    xbmcplugin.endOfDirectory(HANDLE)

# --- PREMIUM (MANDRAKODI SOURCE) ---

# Hardcoded config (no remote fetch to avoid load-time issues)
PREMIUM_URL = "https://test34344.herokuapp.com/filter.php"
PREMIUM_UA = "MandraKodi2@@1.1.2@@MandraKodi3@@S63TDC"
PROTECTION_KEY = "amstaff@@"

def list_premium_sport():
    """Show SPORT premium channels directly (no subfolder)"""
    import requests
    xbmcplugin.setContent(HANDLE, 'videos')
    url = f"{PREMIUM_URL}?numTest=A1A260"
    headers = {"User-Agent": PREMIUM_UA}
    
    try:
        r = requests.get(url, headers=headers, timeout=10)
        data = r.json()
        sections = data.get("channels", [])
        
        for sec in sections:
            name = sec.get("name", "Unknown Group")
            # Show channels directly from SPORT sections
            if "SPORT" in name.upper():
                for it in sec.get("items", []):
                    resolve_val = it.get("myresolve", "")
                    if PROTECTION_KEY in resolve_val:
                        payload = resolve_val.split("@@")[1]
                        title = it.get("title", "Canale")
                        add_directory_item(
                            title, 
                            {"action": "play_premium", "payload": payload, "title": title},
                            is_folder=False,
                            is_playable=True,
                            icon=it.get("thumbnail")
                        )
                
    except Exception as e:
        xbmcgui.Dialog().ok("Errore Premium", f"Impossibile caricare i canali Premium: {str(e)}")
        
    xbmcplugin.endOfDirectory(HANDLE)

def list_premium_cinema():
    """Show Cinema, Intrattenimento, and Bambini channels"""
    import requests
    xbmcplugin.setContent(HANDLE, 'videos')
    url = f"{PREMIUM_URL}?numTest=A1A260"
    headers = {"User-Agent": PREMIUM_UA}
    
    try:
        r = requests.get(url, headers=headers, timeout=10)
        data = r.json()
        sections = data.get("channels", [])
        
        for sec in sections:
            name = sec.get("name", "Unknown Group")
            # Show everything EXCEPT Sport (Cinema, Intrattenimento, Bambini)
            if "SPORT" not in name.upper():
                 add_directory_item(name, {"action": "list_premium_category", "cat_data": json.dumps(sec)})
                
    except Exception as e:
        xbmcgui.Dialog().ok("Errore Premium", f"Impossibile caricare i canali Premium: {str(e)}")
        
    xbmcplugin.endOfDirectory(HANDLE)

def list_premium_category(cat_data):
    try:
        sec = json.loads(cat_data)
        items = sec.get("items", [])
        
        for it in items:
            # Mandrakodi uses 'myresolve' with protection key
            resolve_val = it.get("myresolve", "")
            if PROTECTION_KEY in resolve_val:
                payload = resolve_val.split("@@")[1]
                title = it.get("title", "Canale")
                
                # Usa add_directory_item originale o custom?
                # Definiamo azione play_premium
                url = f"{BASE_URL}?action=play_premium&payload={payload}&title={title}"
                li = xbmcgui.ListItem(label=title)
                li.setArt({'icon': it.get("thumbnail"), 'thumb': it.get("thumbnail")})
                li.setProperty('IsPlayable', 'true')
                xbmcplugin.addDirectoryItem(handle=HANDLE, url=url, listitem=li, isFolder=False)
                
    except Exception as e:
        xbmc.log(f"Error list_premium_category: {e}", xbmc.LOGERROR)
        
    xbmcplugin.endOfDirectory(HANDLE)

def play_premium(payload, title):
    import base64
    
    # Fix padding for base64
    missing_padding = len(payload) % 4
    if missing_padding:
        payload += '=' * (4 - missing_padding)
        
    try:
        decoded = base64.b64decode(payload).decode('utf-8')
        parts = decoded.split('|')
        
        stream_url = parts[0]
        clearkey = parts[1] if len(parts) > 1 else None
        
        # NowTV/Sky uses these headers
        ua = "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/119.0.0.0 Safari/537.36"
        host = "https://www.nowtv.it"
        headers = f"User-Agent={ua}&Referer={host}/&Origin={host}&verifypeer=false"
        
        list_item = xbmcgui.ListItem(path=stream_url)
        list_item.setInfo('video', {'title': title})
        
        # Set InputStream Adaptive properties
        list_item.setProperty('inputstream', 'inputstream.adaptive')
        if ".mpd" in stream_url:
            list_item.setProperty('inputstream.adaptive.file_type', 'mpd')
            list_item.setMimeType("application/dash+xml")
        elif ".m3u8" in stream_url:
            list_item.setProperty('inputstream.adaptive.file_type', 'hls')
            list_item.setMimeType("application/x-mpegURL")
            
        if clearkey and clearkey != "0000":
            list_item.setProperty('inputstream.adaptive.drm_legacy', f'org.w3.clearkey|{clearkey}')
            
        list_item.setProperty('inputstream.adaptive.stream_headers', headers)
        list_item.setProperty('inputstream.adaptive.manifest_headers', headers)
        
        xbmcplugin.setResolvedUrl(HANDLE, True, listitem=list_item)
        
    except Exception as e:
        xbmcgui.Dialog().notification("Errore Play", f"Errore decodifica: {str(e)}", xbmcgui.NOTIFICATION_ERROR)

# --- FREESHOT (SKY SPORT LIVE) ---

def list_freeshot():
    """Lista canali Sky Sport via Freeshot (da config remota)"""
    xbmcplugin.setContent(HANDLE, 'videos')
    
    cfg = get_remote_config()
    channels = cfg.get("freeshot", {}).get("channels", [])
    
    for ch in channels:
        add_directory_item(
            ch["name"],
            {"action": "play_freeshot", "code": ch["code"], "title": ch["name"]},
            is_folder=False,
            is_playable=True
        )
        
    xbmcplugin.endOfDirectory(HANDLE)

def play_freeshot(code, title):
    """Risolvi e riproduci un canale Freeshot (endpoint da config remota)"""
    import requests
    
    try:
        cfg = get_remote_config().get("freeshot", {})
        player_base = cfg.get("player_base_url", "https://popcdn.day/player/")
        stream_base = cfg.get("stream_base_url", "https://planetary.lovecdn.ru/")
        stream_path = cfg.get("stream_path", "/tracks-v1a1/mono.m3u8")
        referer = cfg.get("referer", "https://thisnot.business/")
        token_regex = cfg.get("token_regex", 'currentToken: "([^"]+)"')
        
        xbmc.log(f"[CBTV] Freeshot: risolvendo {title} ({code})", xbmc.LOGINFO)
        
        ua = "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/135.0.0.0 Safari/537.36 OPR/120.0.0.0"
        
        # Step 1: Ottieni il token
        s = requests.Session()
        headers = {'User-Agent': ua, 'Referer': referer}
        page_url = f"{player_base}{code}"
        
        r = s.get(page_url, headers=headers, timeout=10)
        
        match = re.search(token_regex, r.text)
        if not match:
            raise Exception(f"Token non trovato per {code}")
            
        token = match.group(1)
        xbmc.log(f"[CBTV] Freeshot token ottenuto: {token[:30]}...", xbmc.LOGINFO)
        
        # Step 2: Costruisci URL stream
        stream_url = f"{stream_base}{code}{stream_path}?token={token}"
        xbmc.log(f"[CBTV] Freeshot stream: {stream_url}", xbmc.LOGINFO)
        
        # Step 3: Play con inputstream.ffmpegdirect
        list_item = xbmcgui.ListItem(path=stream_url)
        list_item.setInfo('video', {'title': title})
        list_item.setProperty('inputstream', 'inputstream.ffmpegdirect')
        list_item.setProperty('inputstream.ffmpegdirect.is_realtime_stream', 'true')
        list_item.setProperty('inputstream.ffmpegdirect.manifest_type', 'hls')
        list_item.setMimeType('application/x-mpegURL')
        list_item.setContentLookup(False)
        
        xbmcplugin.setResolvedUrl(HANDLE, True, listitem=list_item)
        
    except Exception as e:
        xbmc.log(f"[CBTV] Errore Freeshot: {str(e)}", xbmc.LOGERROR)
        xbmcgui.Dialog().notification("Errore Freeshot", str(e), xbmcgui.NOTIFICATION_ERROR)
        xbmcplugin.setResolvedUrl(HANDLE, False, xbmcgui.ListItem())

# --- MEDIAHOSTING (SKY SPORT 2 - Backup) ---

def list_mediahosting():
    """Lista canali Sky Sport via Mediahosting (da config remota)"""
    xbmcplugin.setContent(HANDLE, 'videos')
    
    cfg = get_remote_config()
    channels = cfg.get("mediahosting", {}).get("channels", [])
    
    for ch in channels:
        add_directory_item(
            ch["name"],
            {"action": "play_mediahosting", "code": ch["code"], "title": ch["name"]},
            is_folder=False,
            is_playable=True
        )
        
    xbmcplugin.endOfDirectory(HANDLE)

def play_mediahosting(code, title):
    """Risolvi e riproduci un canale Mediahosting (endpoint da config remota)"""
    import requests
    
    try:
        cfg = get_remote_config().get("mediahosting", {})
        embed_base = cfg.get("embed_base_url", "https://mediahosting.space/embed/player?stream=")
        referer = cfg.get("referer", "https://mediahosting.space/")
        source_regex = cfg.get("source_regex", '<source src="(.*?)"')
        
        xbmc.log(f"[CBTV] Mediahosting: risolvendo {title} (stream {code})", xbmc.LOGINFO)
        
        # Step 1: Ottieni URL stream dalla pagina embed
        player_url = f"{embed_base}{code}"
        headers = {'Referer': referer}
        
        r = requests.get(player_url, headers=headers, timeout=15)
        
        match = re.search(source_regex, r.text)
        if not match:
            raise Exception(f"Stream URL non trovato per stream {code}")
            
        stream_url = match.group(1)
        xbmc.log(f"[CBTV] Mediahosting stream: {stream_url}", xbmc.LOGINFO)
        
        # Step 2: Play diretto (URL HLS standard .m3u8)
        list_item = xbmcgui.ListItem(path=stream_url)
        list_item.setInfo('video', {'title': title})
        list_item.setProperty('inputstream', 'inputstream.ffmpegdirect')
        list_item.setProperty('inputstream.ffmpegdirect.is_realtime_stream', 'true')
        list_item.setProperty('inputstream.ffmpegdirect.manifest_type', 'hls')
        list_item.setMimeType('application/x-mpegURL')
        list_item.setContentLookup(False)
        
        xbmcplugin.setResolvedUrl(HANDLE, True, listitem=list_item)
        
    except Exception as e:
        xbmc.log(f"[CBTV] Errore Mediahosting: {str(e)}", xbmc.LOGERROR)
        xbmcgui.Dialog().notification("Errore Mediahosting", str(e), xbmcgui.NOTIFICATION_ERROR)
        xbmcplugin.setResolvedUrl(HANDLE, False, xbmcgui.ListItem())

# --- AGENDA (SCRAPER) ---

# --- AGENDA INTELLIGENTE (EPG DRIVEN) ---

def get_today_dates():
    from datetime import datetime
    now = datetime.now()
    today = now.strftime("%Y-%m-%d")
    return today

def get_cache_path(filename):
    """Ritorna il percorso della cache per l'addon"""
    path = xbmcvfs.translatePath(ADDON.getAddonInfo('profile'))
    if not os.path.exists(path):
        os.makedirs(path)
    return os.path.join(path, filename)

def download_xmltv_cached(url, name):
    """Scarica XMLTV e lo salva in cache per 24 ore"""
    import requests
    cache_file = get_cache_path(f"epg_{name}.xml")
    
    # Controlla se il file esiste ed è recente
    if os.path.exists(cache_file):
        mtime = os.path.getmtime(cache_file)
        if datetime.now().timestamp() - mtime < 86400: # 24 ore
            return cache_file
            
    try:
        xbmc.log(f"[CBTV] Scaricando XMLTV {name} da {url}", xbmc.LOGINFO)
        r = requests.get(url, headers=HEADERS, timeout=15)
        if r.status_code == 200:
            with open(cache_file, "wb") as f:
                f.write(r.content)
            return cache_file
        else:
            xbmc.log(f"[CBTV] Errore download XMLTV {name}: {r.status_code}", xbmc.LOGWARNING)
    except Exception as e:
        xbmc.log(f"[CBTV] Eccezione download XMLTV {name}: {e}", xbmc.LOGERROR)
    return cache_file if os.path.exists(cache_file) else None

def get_daddylive_schedule():
    """Scraper veloce per il palinsesto sportivo"""
    import requests
    events = []
    
    # Keywords per filtrare (anche campionati specifici se manca "Soccer" nel nome)
    WANTED = [
        "soccer", "tennis", "volleyball", "motorsport", "formula 1", "motogp", "f1",
        "serie a", "serie b", "premier league", "la liga", "bundesliga", "ligue 1", "eredivisie", "liga portugal",
        "champions league", "europa league", "conference league", "coppa italia", "fa cup", "copa del rey",
        "atp", "wta", "davis cup", "slam", "roland garros", "wimbledon", "us open", "australian open",
        "superlega", "a1", "cev"
    ]
    # Filtra sport e leghe non richieste che potrebbero matchare le keyword (es. Darts Champions League, Women's CL)
    UNWANTED = [
        "college", "ncaa", "university", "lovb", "women", "femenino", "femminile", "ladies", "wsl", "uwcl",
        "youth", "u19", "u20", "u21", "u23", "reserve", "reserves", "youth league",
        "futsal", "beach soccer", "indoor",
        "darts", "snooker", "cricket", "rugby", "esports", "badminton", "table tennis", "golf", "cycling", "horse racing",
        "bahrain", "kenya", "uganda", "ethiopia", "tanzania", "rwanda", "zambia", # Africa minor
        "peru", "bolivia", "venezuela", "ecuador", "paraguay", "chile", "uruguay", "colombia", # SA nationals
        "costa rica", "guatemala", "honduras", "el salvador", "nicaragua", "panama",
        "afc ", "caf ", "concacaf" # Filter non-UEFA continental if unwanted (optional, but requested to clean up)
    ]

    try:
        daddy_url = "https://daddylive.sx/"
        r = requests.get(daddy_url, headers=HEADERS, timeout=15)
        if r.status_code != 200: return events
        
        html = r.text
        
        # Split per blocchi evento (Flat parsing, le sezioni sono sparite)
        parts = html.split('<div class="schedule__event">')
        
        # Libera memoria
        del html
        
        for block in parts[1:]:
            # Taglia blocco
            end_idx = min(len(block), 4000)
            block = block[:end_idx]
            
            # Titolo
            t_start = block.find('schedule__eventTitle">')
            if t_start == -1: continue
            t_start += len('schedule__eventTitle">')
            t_end = block.find('</span>', t_start)
            if t_end == -1: continue
            title = block[t_start:t_end].strip()
            
            # FILTRO
            title_lower = title.lower()
            
            # Se è junk, salta
            if any(u in title_lower for u in UNWANTED):
                continue
                
            # Se non è wanted, salta
            if not any(w in title_lower for w in WANTED):
                continue
            
            # Ora
            time_str = "--:--"
            dt_start = block.find('data-time="')
            if dt_start != -1:
                dt_start += len('data-time="')
                dt_end = block.find('"', dt_start)
                if dt_end != -1:
                    time_str = block[dt_start:dt_end].strip() or "--:--"
            
            # Links
            sources = []
            search_pos = 0
            while True:
                a_start = block.find('href="', search_pos)
                if a_start == -1: break
                a_start += len('href="')
                a_end = block.find('"', a_start)
                if a_end == -1: break
                href = block[a_start:a_end]
                
                if "watch" in href.lower():
                    # Nome canale
                    gt = block.find('>', a_end)
                    lt = block.find('</a>', gt)
                    if gt != -1 and lt != -1:
                        ch_name = block[gt+1:lt].strip()
                        if ch_name:
                            full_url = daddy_url.rstrip('/') + href if not href.startswith('http') else href
                            sources.append({"name": ch_name, "url": full_url})
                
                search_pos = a_end + 1
            
            if sources:
                events.append({
                    "title": title, # Lascia titolo originale
                    "time": time_str,
                    "sources": sources
                })
        
    except Exception as e:
        xbmc.log(f"[CBTV] Errore scraping agenda: {e}", xbmc.LOGERROR)
    
    return events



def get_mpd_link_for_foreign(channel_name, country):
    """Cerca un link MPD Amstaff per un canale straniero"""
    # Questa è una mappatura euristica. In futuro potremmo scaricare la lista MPD e matchare.
    # Per ora usiamo i canali principali conosciuti.
    mapping = {
        "MOVISTAR LALIGA": "amstaff@@...", # Esempio
        "CANAL+ SPORT": "amstaff@@...",
    }
    # Per ora restituiamo una label che indica la nazione, la risoluzione avverrà via MPD Nazioni
    return {"name": channel_name, "country": country}

def list_agenda():
    """Agenda Sportiva: Calcio, Tennis, Volley, Motorsport"""
    xbmcplugin.setContent(HANDLE, 'videos')
    p_dialog = xbmcgui.DialogProgress()
    p_dialog.create('CBTV', 'Caricamento agenda...')
    
    p_dialog.update(50, "Scarico palinsesto sportivo...")
    events = get_daddylive_schedule()
    
    # Filtra eventi "doppioni" o di bassa qualità che hanno solo canali "Extra Stream CH-..."
    # Se un evento ha SOLO canali generici, lo scartiamo a favore di quello "buono"
    
    clean_events = []
    for ev in events:
        has_real_channels = False
        for s in ev["sources"]:
            name = s["name"].lower()
            # Se il nome è tipo "extra stream ch-..." o "ch-..." lo consideriamo generico
            if "extra stream" in name or re.match(r'^ch-\d+$', name):
                continue
            has_real_channels = True
            break
            
        if has_real_channels:
            clean_events.append(ev)
            
    # Se non rimangono eventi (caso raro), allora mostriamo tutto per non lasciare vuoto
    if not clean_events and events:
        clean_events = events
        
    events = clean_events
    
    p_dialog.update(80, f"Trovati {len(events)} eventi")
    
    # Salva eventi per l'accesso successivo
    cache_file = get_cache_path("agenda_events.json")
    with open(cache_file, "w", encoding="utf-8") as f:
        json.dump(events, f, ensure_ascii=False)
    
    # Parole chiave per evidenziare
    W_TOP = ["PAOLINI", "SINNER", "MUSETTI", "CEV", "COPPA ITALIA", "SERIE A", "DOHA", "ROTTERDAM", "PREMIER", "NAPOLI", "JUVE", "INTER", "MILAN"]
    
    for idx, ev in enumerate(events):
        title_up = ev["title"].upper()
        is_top = any(w in title_up for w in W_TOP)
        
        # Format label pulita (senza emoji che danno problemi su firestick)
        label = f"[B]{ev['time']}[/B] - {ev['title']}"
        
        if is_top:
            label = f"[COLOR yellow][B]{ev['time']}[/B] - {ev['title']}[/COLOR]"
        
        n = len(ev.get("sources", []))
        list_item = xbmcgui.ListItem(label=f"{label} [COLOR gray]({n} canali)[/COLOR]")
        url = f"{sys.argv[0]}?action=list_sources_agenda&idx={idx}"
        xbmcplugin.addDirectoryItem(handle=HANDLE, url=url, listitem=list_item, isFolder=True)
    
    p_dialog.close()
    
    if not events:
        xbmcgui.Dialog().notification("CBTV", "Nessun evento sportivo oggi", xbmcgui.NOTIFICATION_INFO, 3000)
    
    xbmcplugin.endOfDirectory(HANDLE)

def list_sources_agenda():
    """Mostra i nomi dei canali (solo info, non playable)"""
    params = dict(parse_qsl(sys.argv[2][1:]))
    idx = int(params.get('idx', 0))
    
    cache_file = get_cache_path("agenda_events.json")
    try:
        with open(cache_file, "r", encoding="utf-8") as f:
            events = json.load(f)
        ev = events[idx]
    except:
        xbmcplugin.endOfDirectory(HANDLE)
        return
    
    xbmcplugin.setContent(HANDLE, 'videos')
    
    # Mostra solo i nomi dei canali come informazione (FILTRO NOMI BRUTTI)
    shown_count = 0
    for s in ev.get("sources", []):
        name = s['name']
        name_lower = name.lower()
        if "extra stream" in name_lower or re.match(r'^ch-\d+$', name_lower):
            continue
            
        label = f"📺 {name}"
        list_item = xbmcgui.ListItem(label=label)
        # Non playable - solo informazione
        xbmcplugin.addDirectoryItem(handle=HANDLE, url="", listitem=list_item, isFolder=False)
        shown_count += 1
    
    if shown_count == 0:
        # Se abbiamo filtrato tutto (strano, perché l'agenda dovrebbe aver filtrato gli eventi vuoti), mostriamo tutto
        for s in ev.get("sources", []):
             list_item = xbmcgui.ListItem(label=f"📺 {s['name']}")
             xbmcplugin.addDirectoryItem(handle=HANDLE, url="", listitem=list_item, isFolder=False)
        xbmcgui.Dialog().notification("CBTV", "Nessun canale disponibile", xbmcgui.NOTIFICATION_WARNING, 2000)
    
    xbmcplugin.endOfDirectory(HANDLE)

def play_daddy_direct():
    """Prova a riprodurre un link web diretto"""
    params = dict(parse_qsl(sys.argv[2][1:]))
    url = params.get('url')
    xbmcgui.Dialog().notification("CBTV", "Apertura stream...", xbmcgui.NOTIFICATION_INFO, 3000)
    play_freeshot(url, "Stream")


# --- MPD NAZIONI (MANDRAKODI SPORT SOURCE) ---

MPD_NAZIONI_URL = "https://test34344.herokuapp.com/filter.php?numTest=A1A134A"
MPD_UA = "MandraKodi2@@1.2.78@@MandraKodi3@@S63TDC"

def list_mpd_nazioni():
    """Show list of countries from MPD Nazioni"""
    import requests
    xbmcplugin.setContent(HANDLE, 'videos')
    
    try:
        headers = {"User-Agent": MPD_UA}
        r = requests.get(MPD_NAZIONI_URL, headers=headers, timeout=10)
        data = r.json()
        countries = data.get("channels", [])
        
        for country in countries:
            name = country.get("name", "Unknown")
            # Clean color tags for display
            clean_name = re.sub(r'\[.*?\]', '', name).strip()
            thumb = country.get("thumbnail")
            
            add_directory_item(
                clean_name,
                {"action": "list_mpd_channels", "country_data": json.dumps(country)},
                icon=thumb
            )
    except Exception as e:
        xbmcgui.Dialog().notification("MPD Nazioni", f"Errore: {str(e)}", xbmcgui.NOTIFICATION_ERROR)
    
    xbmcplugin.endOfDirectory(HANDLE)

def list_mpd_channels(country_data):
    """Show channels for selected country"""
    import requests
    xbmcplugin.setContent(HANDLE, 'videos')
    
    try:
        country = json.loads(country_data)
        items = country.get("items", [])
        
        for ch in items:
            title = ch.get("title", "No Title")
            # Clean color tags
            clean_title = re.sub(r'\[.*?\]', '', title).strip()
            thumb = ch.get("thumbnail")
            myresolve = ch.get("myresolve", "")
            
            # Check if this is an MPD channel (has amstaff@@ prefix)
            if myresolve and "@@" in myresolve:
                # Make it a FOLDER that opens a submenu (like Mandrakodi)
                add_directory_item(
                    f"[COLOR cyan]{clean_title}[/COLOR]",
                    {"action": "show_mpd_play", "resolve_data": myresolve, "channel_name": clean_title},
                    is_folder=True,  # Changed to True - opens submenu
                    is_playable=False,
                    icon=thumb
                )
    except Exception as e:
        xbmcgui.Dialog().notification("MPD Canali", f"Errore: {str(e)}", xbmcgui.NOTIFICATION_ERROR)
    
    xbmcplugin.endOfDirectory(HANDLE)

def show_mpd_play(resolve_data, channel_name):
    """Show 'PLAY STREAM' option for the selected channel (Mandrakodi-style)"""
    xbmcplugin.setContent(HANDLE, 'videos')
    
    try:
        # Extract payload after @@
        payload = resolve_data.split("@@")[1]
        
        # Check if payload is a direct URL or Base64-encoded
        if payload.startswith("http://") or payload.startswith("https://"):
            # Direct URL format (e.g., RAI Sport)
            # Format: https://example.com/stream.mpd|0000 or |KID:KEY
            parts = payload.split("|")
            stream_url = parts[0]
            license_data = parts[1] if len(parts) > 1 else ""
        else:
            # Base64-encoded format (most channels)
            # Add padding if needed
            missing_padding = len(payload) % 4
            if missing_padding:
                payload += '=' * (4 - missing_padding)
            
            # Decode Base64
            decoded = base64.b64decode(payload).decode('utf-8')
            parts = decoded.split("|")
            stream_url = parts[0]
            license_data = parts[1] if len(parts) > 1 else ""
        
        # Create ListItem with path already set (like Mandrakodi)
        list_item = xbmcgui.ListItem(label="[COLOR lime]PLAY STREAM[/COLOR]", path=stream_url, offscreen=True)
        list_item.setInfo('video', {'title': channel_name})
        list_item.setProperty('IsPlayable', 'true')
        list_item.setContentLookup(False)
        
        # Set inputstream.adaptive
        list_item.setProperty('inputstream', 'inputstream.adaptive')
        
        # Set MIME type for MPD
        if ".mpd" in stream_url:
            list_item.setMimeType("application/dash+xml")
        
        # Set Clearkey DRM using drm_legacy (like Mandrakodi does!)
        # Note: license_data="0000" means no DRM (unencrypted stream)
        if license_data and ":" in license_data and license_data != "0000":
            drm_type = "org.w3.clearkey"
            # Format: org.w3.clearkey|KID:KEY
            list_item.setProperty('inputstream.adaptive.drm_legacy', f"{drm_type}|{license_data}")
        
        # Add as directory item
        xbmcplugin.addDirectoryItem(
            handle=HANDLE,
            url=stream_url,
            listitem=list_item,
            isFolder=False
        )
        
    except Exception as e:
        xbmcgui.Dialog().notification("MPD Play", f"Errore: {str(e)}", xbmcgui.NOTIFICATION_ERROR)
    
    xbmcplugin.endOfDirectory(HANDLE)

def play_mpd(resolve_data):
    """Decode and play MPD stream with Clearkey DRM"""
    try:
        # Extract payload after @@
        payload = resolve_data.split("@@")[1]
        
        # Check if payload is a direct URL or Base64-encoded
        if payload.startswith("http://") or payload.startswith("https://"):
            # Direct URL format (e.g., RAI Sport)
            parts = payload.split("|")
            stream_url = parts[0]
            license_data = parts[1] if len(parts) > 1 else ""
        else:
            # Base64-encoded format (most channels)
            # Add padding if needed
            missing_padding = len(payload) % 4
            if missing_padding:
                payload += '=' * (4 - missing_padding)
            
            # Decode Base64
            decoded = base64.b64decode(payload).decode('utf-8')
            
            # Parse URL|KID:KEY format
            parts = decoded.split("|")
            stream_url = parts[0]
            license_data = parts[1] if len(parts) > 1 else ""
        
        # Create ListItem for playback
        list_item = xbmcgui.ListItem(path=stream_url)
        
        # Set inputstream.adaptive for MPD playback
        list_item.setProperty('inputstream', 'inputstream.adaptive')
        list_item.setProperty('inputstream.adaptive.manifest_type', 'mpd')
        
        # Set Clearkey DRM if license key is provided
        # Note: license_data="0000" means no DRM (unencrypted stream)
        if license_data and ":" in license_data and license_data != "0000":
            # Split KID:KEY
            kid_key = license_data.split(":")
            kid = kid_key[0]
            key = kid_key[1]
            
            # Clearkey format for inputstream.adaptive
            # Some versions want JSON, others accept KID:KEY directly
            # Try the simple format first
            list_item.setProperty('inputstream.adaptive.license_type', 'clearkey')
            list_item.setProperty('inputstream.adaptive.license_key', license_data)
            
            # Alternative: Try JSON format (commented out for now)
            # clearkey_json = json.dumps({
            #     "keys": [{
            #         "kty": "oct",
            #         "kid": kid,
            #         "k": key
            #     }]
            # })
            # list_item.setProperty('inputstream.adaptive.license_key', clearkey_json)
        
        xbmcplugin.setResolvedUrl(HANDLE, True, list_item)
        
    except Exception as e:
        xbmcgui.Dialog().notification("Play MPD", f"Errore: {str(e)}", xbmcgui.NOTIFICATION_ERROR)
        xbmcplugin.setResolvedUrl(HANDLE, False, xbmcgui.ListItem())

def get_sky_epg(channel_ids):
    """Scarica EPG corrente da Sky IT per la lista di ID"""
    try:
        now = datetime.now()
        # Richiediamo dati per le prossime 4 ore
        end = now + timedelta(hours=4)
        
        # Formato data ISO8601 clean (senza microsecondi)
        ids_str = ",".join(map(str, channel_ids))
        # Aggiunti pageNum e pageSize obbligatori
        url = f"https://apid.sky.it/gtv/v1/events?from={now.strftime('%Y-%m-%dT%H:%M:%SZ')}&to={end.strftime('%Y-%m-%dT%H:%M:%SZ')}&env=DTH&channels={ids_str}&pageNum=0&pageSize=999"
        
        r = requests.get(url, timeout=20)
        if r.status_code == 200:
            evs = r.json().get("events", [])
            xbmc.log(f"[CBTV] EPG Scaricata: {len(evs)} eventi", xbmc.LOGINFO)
            return evs
        else:
            xbmc.log(f"[CBTV] EPG HTTP Error: {r.status_code}", xbmc.LOGERROR)
    except Exception as e:
        xbmc.log(f"[CBTV] EPG Error: {e}", xbmc.LOGERROR)
    return []

def list_epg_entertainment():
    """Mostra EPG pura (solo informativa) per canali cinema/intrattenimento"""
    xbmcplugin.setContent(HANDLE, 'videos')
    
    # 1. Config canali richiesti
    cfg = get_remote_config()
    ent_channels = cfg.get("entertainment", [])
    if not ent_channels:
        xbmcgui.Dialog().notification("CBTV", "Nessun canale configurato", xbmcgui.NOTIFICATION_WARNING)
        xbmcplugin.endOfDirectory(HANDLE)
        return

    # 2. Scarica EPG
    p_dialog = xbmcgui.DialogProgress()
    p_dialog.create('CBTV', 'Scarico Guida TV...')
    
    ids = [c["sky_id"] for c in ent_channels]
    epg_events = get_sky_epg(ids)
    
    p_dialog.close()
    
    if not epg_events:
        # Mostra errore visibile per debug
        now_str = datetime.now().strftime("%H:%M")
        xbmcgui.Dialog().notification("Guida TV", f"Nessun dato (Ora: {now_str})", xbmcgui.NOTIFICATION_ERROR)
    
    # 3. Mostra lista
    for ch in ent_channels:
        curr_event = None
        next_event = None
        
        # Filtra eventi per questo canale
        ch_evs = [e for e in epg_events if str(e.get("channel", {}).get("id")) == str(ch["sky_id"])]
        
        if ch_evs:
            curr_event = ch_evs[0]
            if len(ch_evs) > 1: next_event = ch_evs[1]
        
        title_display = ch["name"]
        plot = "Nessun evento disponibile."
        icon = ""
        
        if curr_event:
            evt_title = curr_event.get("eventTitle", "")
            evt_sub = curr_event.get("eventSubTitle", "")
            full_t = f"{evt_title} - {evt_sub}" if evt_sub else evt_title
            
            title_display = f"[COLOR yellow][B]{ch['name']}[/B][/COLOR]: {full_t}"
            plot = curr_event.get("eventSynopsis", "")
            
            if next_event:
                plot += f"\n\n[B]Dopo:[/B] {next_event.get('eventTitle')}"

            if "content" in curr_event and "imagesMap" in curr_event["content"]:
                 imgs = curr_event["content"]["imagesMap"]
                 if imgs:
                     k = list(imgs.keys())[0]
                     if "source" in imgs[k]:
                         icon = "https://images.sky.it/images/" + imgs[k]["source"]
        else:
            title_display = f"[COLOR gray]{ch['name']} (No Dati)[/COLOR]"

        li = xbmcgui.ListItem(label=title_display)
        li.setInfo('video', {'plot': plot, 'title': title_display})
        if icon:
            li.setArt({'thumb': icon, 'icon': icon, 'poster': icon})
            
        # Solo informativo
        xbmcplugin.addDirectoryItem(handle=HANDLE, url="", listitem=li, isFolder=False)
            
    xbmcplugin.endOfDirectory(HANDLE)

# Removed list_epg_entertainment (integrated into Premium)

if __name__ == '__main__':
    params = dict(parse_qsl(sys.argv[2][1:]))
    action = params.get('action')
    
    if not action:
        main_menu()
    elif action == 'list_epg_entertainment':
        list_epg_entertainment()
    elif action == 'list_agenda':
        list_agenda()
    elif action == 'list_sources_agenda':
        list_sources_agenda()
    elif action == 'play_daddy_direct':
        play_daddy_direct()
    elif action == 'list_sport':
        list_sport()
    elif action == 'list_sport_sky':
        list_sport_sky()
    elif action == 'list_premium_sport':
        list_premium_sport()
    elif action == 'list_premium_cinema':
        list_premium_cinema()
    elif action == 'list_premium_category':
        list_premium_category(params.get('cat_data'))
    elif action == 'play_premium':
        play_premium(params.get('payload'), params.get('title'))
    elif action == 'list_mpd_nazioni':
        list_mpd_nazioni()
    elif action == 'list_mpd_channels':
        list_mpd_channels(params.get('country_data'))
    elif action == 'show_mpd_play':
        show_mpd_play(params.get('resolve_data'), params.get('channel_name'))
    elif action == 'play_mpd':
        play_mpd(params.get('resolve_data'))
    elif action == 'list_freeshot':
        list_freeshot()
    elif action == 'play_freeshot':
        play_freeshot(params.get('code'), params.get('title'))
    elif action == 'list_mediahosting':
        list_mediahosting()
    elif action == 'play_mediahosting':
        play_mediahosting(params.get('code'), params.get('title'))
    elif action == 'play_internal':
        play_internal(params.get('url'), params.get('title'))
