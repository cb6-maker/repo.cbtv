import requests

url = "https://cb6-maker.github.io/repo.cbtv/channels_config.json"
r = requests.get(url)

print("Status:", r.status_code)
print("Olanda present?", "Olanda" in r.text)
print("Albania present?", "Albania" in r.text)
print("Repubblica Ceca present?", "Repubblica Ceca" in r.text)

if r.status_code == 200:
    open("remote_channels.json", "w", encoding="utf-8").write(r.text)
