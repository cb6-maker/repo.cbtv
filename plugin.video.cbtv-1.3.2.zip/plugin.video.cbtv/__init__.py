# Kodi addon init file
